from django.urls import path

from .views import AttractionDetailView, AttractionListView, hive_pointer

app_name = "travel"

urlpatterns = [
    path("hive-pointer/", hive_pointer, name="hive-pointer"),
    path("attractions/", AttractionListView.as_view(), name="attraction-list"),
    path("attractions/<int:poi_id>/", AttractionDetailView.as_view(), name="attraction-detail"),
]
