from django.conf import settings
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView

from .services import fetch_attraction_detail, fetch_attractions


@api_view(["GET"])
def hive_pointer(_request):
    """返回 Hive 中存储的表信息，供大数据模块联动时填写。"""
    return Response(
        {
            "hive_database": settings.HIVE_CONFIG.get("database", "default"),
            "hive_table": settings.HIVE_CONFIG.get("table", "dwd_attractions"),
            "description": "旅游 POI + 用户行为离线数据存放于 Hive 集群",
        }
    )


class AttractionListView(APIView):
    """分页 + 筛选的旅游数据列表"""

    def get(self, request):
        page = int(request.query_params.get("page", 1))
        page_size = int(
            request.query_params.get("page_size", settings.API_DEFAULT_PAGE_SIZE)
        )
        filters = {
            "keyword": request.query_params.get("keyword"),
            "district": request.query_params.get("district"),
            "sightLevel": request.query_params.get("sightLevel"),
            "minPrice": request.query_params.get("minPrice"),
            "maxPrice": request.query_params.get("maxPrice"),
            "tagName": request.query_params.get("tagName"),
        }

        try:
            data = fetch_attractions(page, page_size, filters)
        except Exception as exc:  # pragma: no cover
            print(exc)
            return Response(
                {"detail": f"Hive 查询失败: {exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )
        return Response(data)


class AttractionDetailView(APIView):
    """单个景点详情"""

    def get(self, request, poi_id: int):
        try:
            detail = fetch_attraction_detail(poi_id)
        except Exception as exc:  # pragma: no cover
            return Response(
                {"detail": f"Hive 查询失败: {exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )
        if not detail:
            return Response(status=status.HTTP_404_NOT_FOUND)
        return Response(detail)
