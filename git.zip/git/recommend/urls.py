from django.urls import path

from .views import (
    DashboardSummaryView,
    DNNRankRecommendView,
    ForePageView,
    IndexSummaryView,
    MultimodalRecommendView,
    TrainDNNRankView,
    TrainMultimodalView,
    TrainUserCFView,
    UserCFRecommendView,
)

app_name = "recommend"

urlpatterns = [
    path("summary/", DashboardSummaryView.as_view(), name="dashboard-summary"),
    path("index/", IndexSummaryView.as_view(), name="index-dashboard-summary"),
    path("fore/<slug:page>/", ForePageView.as_view(), name="fore-page"),
    path("user-cf/", UserCFRecommendView.as_view(), name="user-cf"),
    path("multimodal/", MultimodalRecommendView.as_view(), name="multimodal"),
    path("dnn-rank/", DNNRankRecommendView.as_view(), name="dnn-rank"),
    path("train/user-cf/", TrainUserCFView.as_view(), name="train-user-cf"),
    path("train/multimodal/", TrainMultimodalView.as_view(), name="train-multimodal"),
    path("train/dnn-rank/", TrainDNNRankView.as_view(), name="train-dnn-rank"),
]
