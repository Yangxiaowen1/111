from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, List, Sequence
import json
import math

from django.conf import settings
from pyhive import hive


TABLE_KEYS_BIG = {
    "cards": "cards",
    "mapHeat": "map_heat",
    "wordCloud": "word_cloud",
    "scoreTrend": "score_trend",
    "categoryBreakdown": "category_breakdown",
    "scoreDistribution": "score_distribution",
    "priceRange": "price_range",
    "topTable": "top_table",
    "recommendations": "recommendations",
}

TABLE_KEYS_INDEX = {
    "cards": "cards",
    "cityOverview": "city_overview",
    "categoryMatrix": "category_matrix",
    "priceTrend": "price_trend",
    "recentTrend": "recent_trend",
    "hotTags": "hot_tags",
    "featuredList": "featured_list",
}

FORE_PAGE_TABLES: Dict[str, Dict[str, str]] = {
    "condition": {
        "cityInsight": "filter_city",
        "levelBreakdown": "filter_level",
        "tagHot": "filter_tags",
        "bookingStats": "filter_booking",
        "priceBuckets": "filter_price",
    },
    "price": {
        "distribution": "price_distribution",
        "discount": "price_discount",
        "scatter": "price_vs_score",
        "paidCompare": "price_paid_rate",
        "topList": "price_top",
    },
    "family": {
        "tags": "family_tags",
        "district": "family_district",
        "levels": "family_level",
        "heat": "family_heat",
        "booking": "family_booking",
    },
    "media": {
        "video": "media_video",
        "distance": "media_distance",
        "opening": "media_opening",
        "events": "media_event",
        "priceTag": "media_price_tag",
    },
}


def _normalize(value):
    if isinstance(value, Decimal):
        value = float(value)
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
    return value


def _fetch_table(cursor, database: str, table: str) -> List[Dict[str, object]]:
    cursor.execute(f"SELECT * FROM {database}.{table}")
    columns = [meta[0] for meta in cursor.description]
    rows = cursor.fetchall()
    result = []
    for row in rows:
        record = {columns[idx]: _normalize(value) for idx, value in enumerate(row)}
        result.append(record)
    return result


def _fetch_payload(conf: dict, table_keys: Dict[str, str]) -> Dict[str, object]:
    prefix = conf["TABLE_PREFIX"]
    connection = hive.Connection(
        host=conf["HOST"],
        port=conf["PORT"],
        username=conf.get("USERNAME"),
        password=conf.get("PASSWORD") or None,
        database=conf["DATABASE"],
    )
    try:
        payload: Dict[str, object] = {}
        for key, suffix in table_keys.items():
            cursor = connection.cursor()
            try:
                payload[key] = _fetch_table(cursor, conf["DATABASE"], f"{prefix}{suffix}")
            finally:
                cursor.close()
        cards = payload.get("cards") or [{}]
        payload["cards"] = cards[0] if isinstance(cards, list) and cards else cards
        payload["generatedAt"] = datetime.now(timezone.utc).isoformat()
        return payload
    finally:
        connection.close()


def fetch_dashboard_payload() -> Dict[str, object]:
    return _fetch_payload(settings.HIVE_DASHBOARD, TABLE_KEYS_BIG)


def fetch_index_payload() -> Dict[str, object]:
    return _fetch_payload(settings.HIVE_INDEX, TABLE_KEYS_INDEX)


def fetch_fore_page_payload(page: str) -> Dict[str, object]:
    tables = FORE_PAGE_TABLES.get(page)
    if not tables:
        raise KeyError(f"未知的可视化页面：{page}")
    conf = settings.HIVE_FOREPAGE
    connection = hive.Connection(
        host=conf["HOST"],
        port=conf["PORT"],
        username=conf.get("USERNAME"),
        password=conf.get("PASSWORD") or None,
        database=conf["DATABASE"],
    )
    try:
        payload: Dict[str, object] = {"generatedAt": datetime.now(timezone.utc).isoformat()}
        cursor = connection.cursor()
        try:
            for key, suffix in tables.items():
                table_name = f"{conf['TABLE_PREFIX']}{suffix}"
                payload[key] = _fetch_table(cursor, conf["DATABASE"], table_name)
        finally:
            cursor.close()
        return payload
    finally:
        connection.close()


def fetch_attractions_by_ids(poi_ids: Sequence[int]) -> List[Dict[str, object]]:
    if not poi_ids:
        return []
    cfg = settings.HIVE_CONFIG
    table = cfg.get("table", "dwd_attractions")
    ids_str = ",".join(str(int(p)) for p in poi_ids)
    sql = f"""
        SELECT poiId, poiName, districtName, zoneName, sightLevelStr, commentScore, heatScore,
               price, marketPrice, tagNameList, shortFeatures, detailUrl, coverImageUrl
        FROM {table}
        WHERE poiId IN ({ids_str})
    """
    connection = hive.Connection(
        host=cfg["host"],
        port=cfg["port"],
        username=cfg.get("username"),
        password=cfg.get("password") or None,
        database=cfg.get("database", "default"),
    )
    cursor = connection.cursor()
    try:
        cursor.execute(sql)
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
    finally:
        cursor.close()
        connection.close()

    results = []
    for row in rows:
        record = dict(zip(columns, row))
        for key in ("price", "marketPrice", "commentScore", "heatScore"):
            if record.get(key) is not None:
                record[key] = float(record[key])
        for key in ("tagNameList", "shortFeatures"):
            value = record.get(key)
            if isinstance(value, str):
                try:
                    record[key] = json.loads(value)
                except json.JSONDecodeError:
                    record[key] = value
        record["poiId"] = int(record["poiId"])
        results.append(record)
    return results

