from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from recommend.recommender.dnn_rank import DNNRankRecommender, DNNRankTrainer, DNNRankConfig
from recommend.recommender.multimodal import MultimodalRecommender, MultimodalEmbeddingBuilder
from recommend.recommender.user_cf import UserCFRecommender, UserCFTrainer, TrainingConfig
from .services import (
    fetch_attractions_by_ids,
    fetch_dashboard_payload,
    fetch_fore_page_payload,
    fetch_index_payload,
)


class DashboardSummaryView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        try:
            payload = fetch_dashboard_payload()
        except Exception as exc:  # pylint: disable=broad-except
            return Response(
                {"detail": f"Hive 查询失败：{exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )
        return Response(payload)


class IndexSummaryView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        try:
            payload = fetch_index_payload()
        except Exception as exc:  # pylint: disable=broad-except
            return Response(
                {"detail": f"Hive 查询失败：{exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )
        return Response(payload)


class ForePageView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, page: str):
        try:
            payload = fetch_fore_page_payload(page)
        except KeyError:
            return Response({"detail": "未找到对应的可视化页面"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as exc:  # pylint: disable=broad-except
            return Response(
                {"detail": f"Hive 查询失败：{exc}"},
                status=status.HTTP_502_BAD_GATEWAY,
            )
        return Response(payload)


class UserCFRecommendView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        user_id = request.query_params.get("user_id")
        if not user_id:
            return Response({"detail": "需要提供 user_id 参数"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user_id_int = int(user_id)
        except ValueError:
            return Response({"detail": "user_id 参数格式不正确"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            recommender = UserCFRecommender()
            poi_ids = recommender.recommend(user_id_int, top_k=10)
        except FileNotFoundError:
            return Response({"detail": "模型尚未训练，请先运行 train_user_cf"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        if not poi_ids:
            return Response({"userId": user_id_int, "results": []})
        attractions = fetch_attractions_by_ids(poi_ids)
        ordered = sorted(attractions, key=lambda item: poi_ids.index(item["poiId"]))
        return Response({"userId": user_id_int, "results": ordered})


class MultimodalRecommendView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        poi_id = request.query_params.get("poi_id")
        if not poi_id:
            return Response({"detail": "需要提供 poi_id 参数"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            poi_id_int = int(poi_id)
        except ValueError:
            return Response({"detail": "poi_id 参数格式不正确"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            recommender = MultimodalRecommender()
            poi_ids = recommender.recommend(poi_id_int, top_k=12)
        except FileNotFoundError:
            return Response({"detail": "多模态模型尚未构建，请先运行 build_multimodal_embeddings"}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
        if not poi_ids:
            return Response({"poiId": poi_id_int, "results": []})
        attractions = fetch_attractions_by_ids(poi_ids)
        ordered = sorted(attractions, key=lambda item: poi_ids.index(item["poiId"]))
        return Response({"poiId": poi_id_int, "results": ordered})


class DNNRankRecommendView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        user_id = request.query_params.get("user_id")
        if not user_id:
            return Response({"detail": "需要提供 user_id 参数"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user_id_int = int(user_id)
        except ValueError:
            return Response({"detail": "user_id 参数格式不正确"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            recommender = DNNRankRecommender()
            poi_ids = recommender.recommend(user_id_int, top_k=12)
        except FileNotFoundError:
            return Response(
                {"detail": "排序模型尚未训练，请先运行 train_dnn_rank"},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )
        if not poi_ids:
            return Response({"userId": user_id_int, "results": []})
        attractions = fetch_attractions_by_ids(poi_ids)
        ordered = sorted(attractions, key=lambda item: poi_ids.index(item["poiId"]))
        return Response({"userId": user_id_int, "results": ordered})


class TrainUserCFView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        try:
            cfg = TrainingConfig()
            trainer = UserCFTrainer(config=cfg)
            trainer.train()
        except Exception as exc:  # pylint: disable=broad-except
            return Response({"detail": f"UserCF 训练失败：{exc}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response({"detail": "UserCF 模型训练完成"}, status=status.HTTP_200_OK)


class TrainMultimodalView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        try:
            builder = MultimodalEmbeddingBuilder()
            builder.build()
        except Exception as exc:  # pylint: disable=broad-except
            return Response({"detail": f"多模态模型构建失败：{exc}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response({"detail": "多模态 Embedding 构建完成"}, status=status.HTTP_200_OK)


class TrainDNNRankView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        try:
            cfg = DNNRankConfig()
            trainer = DNNRankTrainer(config=cfg)
            trainer.train()
        except Exception as exc:  # pylint: disable=broad-except
            return Response({"detail": f"DNN 排序模型训练失败：{exc}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response({"detail": "DNN 排序模型训练完成"}, status=status.HTTP_200_OK)

