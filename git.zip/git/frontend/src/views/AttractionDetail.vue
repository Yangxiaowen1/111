<template>
  <div class="detail-page" v-loading="loading">
    <el-page-header @back="$router.back()" content="景点详情" class="mb-16" />

    <el-card v-if="detail" class="base-card" shadow="hover">
      <div class="base-info">
        <el-image
          :src="detail.coverImageUrl"
          fit="cover"
          class="cover"
          :preview-src-list="[detail.coverImageUrl]"
        >
          <div slot="error" class="image-slot">
            <i class="el-icon-picture-outline" />
          </div>
        </el-image>
        <div class="meta">
          <h2>{{ detail.poiName }}</h2>
          <p class="sub">
            {{ detail.districtName }} · {{ detail.zoneName || '暂无商圈' }}
            <el-tag v-if="detail.sightLevelStr" type="success" size="mini">
              {{ detail.sightLevelStr }}
            </el-tag>
          </p>
          <p class="desc">{{ detail.shortFeatures || '暂无简介' }}</p>
          <div class="stats">
            <div>评分：<strong>{{ detail.commentScore || '-' }}</strong></div>
            <div>热度：<strong>{{ detail.heatScore || '-' }}</strong></div>
            <div>评论数：<strong>{{ detail.commentCount || 0 }}</strong></div>
          </div>
          <div class="actions">
            <el-button type="primary" @click="openOfficial" :disabled="!detail.detailUrl">
              打开官方网站
            </el-button>
            <el-button
              type="warning"
              plain
              :loading="favoriteLoading"
              @click="toggleFavorite"
            >
              {{ isFavorite ? '取消收藏' : '收藏' }}
            </el-button>
          </div>
        </div>
        <div class="price-box">
          <div class="label">低至</div>
          <div class="price">{{ formatPrice(detail.price) }}</div>
          <small v-if="detail.marketPrice">门市价：￥{{ detail.marketPrice }}</small>
        </div>
      </div>
      <div class="tag-block">
        <el-tag v-for="tag in formatTags(detail.tagNameList)" :key="tag" size="medium" type="info">
          {{ tag }}
        </el-tag>
      </div>
    </el-card>

    <el-row :gutter="20">
      <el-col :span="14">
        <el-card shadow="never" class="comment-card">
          <div slot="header" class="card-header">
            <span>用户评论</span>
            <el-button type="text" @click="fetchComments">刷新</el-button>
          </div>
          <el-empty v-if="!comments.length" description="暂时还没有评论" />
          <el-timeline v-else>
            <el-timeline-item
              v-for="item in comments"
              :key="item.id"
              :timestamp="formatTime(item.occurred_at)"
            >
              <div class="comment-item">
                <div class="comment-header">
                  <strong>{{ item.nickname || item.user }}</strong>
                  <el-rate :value="item.rating" disabled show-score :max="5" />
                </div>
                <p class="comment-content">{{ item.content || '该用户很懒，什么都没说~' }}</p>
                <div v-if="item.images && item.images.length" class="comment-images">
                  <el-image
                    v-for="img in item.images"
                    :key="img"
                    :src="img"
                    fit="cover"
                    :preview-src-list="item.images"
                  />
                </div>
              </div>
            </el-timeline-item>
          </el-timeline>
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card shadow="never" class="form-card">
          <div slot="header">发表评论</div>
          <el-form :model="commentForm" label-width="80px">
            <el-form-item label="评分">
              <el-rate v-model="commentForm.rating" show-score />
            </el-form-item>
            <el-form-item label="内容">
              <el-input
                v-model="commentForm.content"
                type="textarea"
                :rows="4"
                placeholder="分享你的游玩体验"
              />
            </el-form-item>
            <el-form-item label="图片链接">
              <el-input
                v-model="commentForm.images"
                placeholder="多图用英文逗号分隔"
              />
            </el-form-item>
            <el-form-item>
              <el-button
                type="primary"
                :loading="commentLoading"
                @click="submitComment"
              >
                提交评论
              </el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import api from '@/services/api';

export default {
  name: 'AttractionDetail',
  props: {
    poiId: {
      type: [String, Number],
      required: true
    }
  },
  data() {
    return {
      detail: null,
      loading: false,
      favoriteLoading: false,
      isFavorite: false,
      comments: [],
      commentForm: {
        rating: 5,
        content: '',
        images: ''
      },
      commentLoading: false
    };
  },
  computed: {
    ...mapState(['currentUser']),
    userId() {
      return this.currentUser?.id;
    }
  },
  watch: {
    poiId: {
      immediate: true,
      handler() {
        this.loadDetail();
        this.fetchComments();
        this.fetchFavoriteStatus();
      }
    },
    userId(newVal, oldVal) {
      if (newVal && newVal !== oldVal) {
        this.fetchFavoriteStatus();
        this.trackDetailView();
      }
    }
  },
  methods: {
    async loadDetail() {
      this.loading = true;
      try {
        const { data } = await api.get(`/travel/attractions/${this.poiId}/`);
        this.detail = data;
        this.trackDetailView();
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '加载详情失败');
      } finally {
        this.loading = false;
      }
    },
    async fetchFavoriteStatus() {
      if (!this.userId) {
        this.isFavorite = false;
        return;
      }
      try {
        const { data } = await api.get('/user/favorites/', {
          params: { user_id: this.userId, poi_id: this.poiId }
        });
        this.isFavorite = data.is_favorite;
      } catch (error) {
        console.warn('获取收藏状态失败', error);
      }
    },
    async toggleFavorite() {
      if (!this.userId) {
        this.$message.warning('请先登录');
        return;
      }
      this.favoriteLoading = true;
      try {
        const { data } = await api.post('/user/favorites/', {
          user_id: this.userId,
          poi_id: this.poiId,
          is_favorite: !this.isFavorite,
          scene: 'detail_page'
        });
        this.isFavorite = data.is_favorite;
        this.$message.success(this.isFavorite ? '收藏成功' : '已取消收藏');
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '操作失败');
      } finally {
        this.favoriteLoading = false;
      }
    },
    async fetchComments() {
      try {
        const { data } = await api.get('/user/comments/', {
          params: { poi_id: this.poiId }
        });
        this.comments = data;
      } catch (error) {
        console.warn('获取评论失败', error);
      }
    },
    async submitComment() {
      if (!this.userId) {
        this.$message.warning('请先登录');
        return;
      }
      if (!this.commentForm.content) {
        this.$message.warning('请输入评论内容');
        return;
      }
      this.commentLoading = true;
      try {
        const images = this.commentForm.images
          ? this.commentForm.images.split(',').map(item => item.trim()).filter(Boolean)
          : [];
        await api.post('/user/comments/', {
          user_id: this.userId,
          poi_id: this.poiId,
          rating: this.commentForm.rating,
          content: this.commentForm.content,
          images
        });
        this.$message.success('评论成功');
        this.commentForm.content = '';
        this.commentForm.images = '';
        this.fetchComments();
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '评论失败');
      } finally {
        this.commentLoading = false;
      }
    },
    async trackDetailView() {
      if (!this.userId) return;
      try {
        await api.post('/user/detail-view/', {
          user_id: this.userId,
          poi_id: this.poiId,
          scene: 'detail_page'
        });
      } catch (error) {
        console.warn('详情行为上报失败', error);
      }
    },
    openOfficial() {
      if (this.detail?.detailUrl) {
        window.open(this.detail.detailUrl, '_blank');
      }
    },
    formatTags(value) {
      if (!value) return [];
      if (Array.isArray(value)) return value;
      if (typeof value === 'string' && value.trim().startsWith('[')) {
        try {
          const parsed = JSON.parse(value);
          if (Array.isArray(parsed)) {
            return parsed.filter(Boolean);
          }
        } catch (error) {
          console.warn('tag 解析失败', error);
        }
      }
      return String(value)
        .split(/[,、;；]/)
        .map(item => item.trim())
        .filter(Boolean);
    },
    formatPrice(value) {
      if (value === null || value === undefined || value === '') return '￥--';
      return `￥${Number(value).toFixed(0)}`;
    },
    formatTime(value) {
      if (!value) return '';
      return new Date(value).toLocaleString();
    }
  }
};
</script>

<style scoped lang="scss">
.detail-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
  color: #1f2d3d;
}

.mb-16 {
  margin-bottom: 16px;
  color: #303133;
}

.base-card {
  margin-bottom: 20px;
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
}

.base-info {
  display: flex;
  align-items: flex-start;
  gap: 24px;
}

.cover {
  width: 260px;
  height: 180px;
  border-radius: 8px;
}

.meta {
  flex: 1;
  h2 {
    margin: 0;
    font-size: 24px;
  }
  .sub {
    margin: 8px 0;
    color: #909399;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .desc {
    color: #606266;
    margin-bottom: 12px;
  }
  .stats {
    display: flex;
    gap: 24px;
    margin-bottom: 12px;
  }
  .actions {
    display: flex;
    gap: 12px;
  }
}

.price-box {
  text-align: center;
  .label {
    color: #909399;
  }
  .price {
    font-size: 32px;
    color: #ff7b24;
    font-weight: 600;
  }
}

.tag-block {
  margin-top: 16px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.comment-card {
  border: none;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
  .comment-item {
    padding: 12px 0;
    border-bottom: 1px solid #f2f2f2;
  }
  .comment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .comment-content {
    margin: 8px 0;
    color: #606266;
  }
  .comment-images {
    display: flex;
    gap: 8px;
    img,
    .el-image {
      width: 80px;
      height: 60px;
      border-radius: 4px;
    }
  }
}

.form-card {
  border: none;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
}
</style>

