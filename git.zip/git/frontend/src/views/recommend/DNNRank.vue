<template>
  <div class="rank-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>深度学习排序推荐（DNN CTR Rank）</h2>
        <p>基于 User / POI Embedding 与多维特征的深度学习点击率预估，为你排序推荐景点</p>
      </div>
      <div class="info">
        当前登录用户：{{ currentUser?.nickname || currentUser?.username || '--' }}
        <el-button type="primary" @click="fetchRecommend" :loading="loading" style="margin-left: 12px">
          刷新排序结果
        </el-button>
        <el-button
          type="warning"
          plain
          size="mini"
          @click="trainModel"
          :loading="trainLoading"
          style="margin-left: 8px"
        >
          重新训练模型
        </el-button>
      </div>
    </div>

    <el-empty v-if="!results.length && !loading" description="暂无推荐，请先训练排序模型或增加行为数据" />

    <div v-else class="card-grid">
      <div v-for="item in results" :key="item.poiId" class="poi-card">
        <div class="cover" :style="{ backgroundImage: `url(${item.coverImageUrl || fallbackImage})` }"></div>
        <div class="meta">
          <div class="title-row">
            <h3>{{ item.poiName }}</h3>
            <el-tag size="mini" v-if="item.sightLevelStr">{{ item.sightLevelStr }}</el-tag>
          </div>
          <p class="desc">
            {{ (item.shortFeatures && item.shortFeatures.join(' / ')) || '暂无简介' }}
          </p>
          <div class="info-row">
            <span><strong>地区：</strong>{{ item.districtName || '--' }}</span>
            <span><strong>价格：</strong>{{ formatPrice(item.price) }}</span>
            <span><strong>热度：</strong>{{ item.heatScore ?? '--' }}</span>
            <span><strong>评分：</strong>{{ item.commentScore ?? '--' }}</span>
          </div>
          <div class="tags">
            <el-tag
              v-for="tag in (item.tagNameList || []).slice(0, 4)"
              :key="tag"
              size="mini"
              effect="plain"
            >
              {{ tag }}
            </el-tag>
          </div>
          <div class="actions">
            <el-button type="primary" plain size="mini" @click="goDetail(item.poiId)">查看详情</el-button>
            <el-link :href="item.detailUrl" target="_blank" type="primary">官网</el-link>
          </div>
        </div>
      </div>
    </div>

    <el-card class="info-card" shadow="never">
      <h3>算法说明：DNN CTR Rank</h3>
      <p>
        本页面采用工业界常见的 DNN 排序模型，将用户行为学习到的 User Embedding、景点 POI Embedding
        与地区、价格、热度、评分等多维特征拼接后，输入多层全连接网络，输出点击率/兴趣得分，再按得分对景点排序。
      </p>
      <ul>
        <li>特征侧：User ID / POI ID Embedding + 地区 Embedding + 价格/热度/评分等数值特征。</li>
        <li>训练数据：来自 MySQL 中的点击、浏览、收藏、评论行为，负采样构造未点击样本。</li>
        <li>模型结构：Embedding → Concatenate → 多层 Dense(64,32) + Dropout → Sigmoid 输出 CTR。</li>
        <li>上线方式：通过 <code>python manage.py train_dnn_rank</code> 离线训练，接口实时读取模型为当前用户打分排序。</li>
      </ul>
    </el-card>
  </div>
</template>

<script>
import api from '@/services/api';
import { mapState } from 'vuex';

export default {
  name: 'DNNRank',
  data() {
    return {
      loading: false,
      results: [],
      fallbackImage: 'https://dummyimage.com/240x160/edf2f7/606266&text=NO+IMAGE',
      retryTimer: null,
      trainLoading: false
    };
  },
  computed: {
    ...mapState(['currentUser'])
  },
  created() {
    this.tryFetch();
  },
  beforeDestroy() {
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
    }
  },
  methods: {
    tryFetch() {
      if (this.currentUser?.id) {
        this.fetchRecommend();
        return;
      }
      this.retryTimer = setTimeout(this.tryFetch, 1000);
    },
    async fetchRecommend() {
      if (!this.currentUser?.id) {
        this.$message.warning('尚未获取到用户信息，请登录或稍后重试');
        return;
      }
      this.loading = true;
      try {
        const { data } = await api.get('/recommend/dnn-rank/', {
          params: { user_id: this.currentUser.id }
        });
        this.results = data.results || [];
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '获取排序推荐失败');
      } finally {
        this.loading = false;
      }
    },
    async trainModel() {
      this.trainLoading = true;
      try {
        const { data } = await api.post('/recommend/train/dnn-rank/');
        this.$message.success(data.detail || 'DNN 排序模型训练完成');
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '模型训练失败');
      } finally {
        this.trainLoading = false;
      }
    },
    formatPrice(value) {
      if (value === null || value === undefined) return '¥--';
      if (Number(value) === 0) return '免费';
      return `¥${Number(value).toFixed(0)}`;
    },
    goDetail(poiId) {
      this.$router.push({ name: 'attraction-detail', params: { poiId } });
    }
  }
};
</script>

<style scoped lang="scss">
.rank-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
  .info {
    display: flex;
    align-items: center;
    font-size: 14px;
    color: #303133;
  }
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
  gap: 16px;
}

.poi-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.cover {
  height: 180px;
  background-size: cover;
  background-position: center;
}

.meta {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  h3 {
    margin: 0;
    font-size: 18px;
  }
}

.desc {
  margin: 0;
  color: #606266;
  min-height: 40px;
}

.info-row {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  font-size: 13px;
  color: #606266;
}

.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 4px;
}

.info-card {
  margin-top: 24px;
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  h3 {
    margin-top: 0;
  }
  ul {
    padding-left: 20px;
    margin-bottom: 0;
  }
}
</style>


