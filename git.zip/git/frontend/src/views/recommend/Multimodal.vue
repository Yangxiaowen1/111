<template>
  <div class="mm-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>多模态相似景点推荐</h2>
        <p>基于图片 + 文本 + 标签 Embedding 的 CLIP 推荐，更智能地发现相似景点</p>
      </div>
      <div class="right">
        <el-form :inline="true" class="form">
          <el-form-item label="景点 ID">
            <el-input v-model="form.poiId" placeholder="输入景点 poiId" clearable />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchRecommend" :loading="loading">获取相似推荐</el-button>
          </el-form-item>
        </el-form>
        <el-button
          type="warning"
          plain
          size="mini"
          @click="trainModel"
          :loading="trainLoading"
          style="margin-left: 8px"
        >
          重新构建多模态向量
        </el-button>
      </div>
    </div>

    <el-empty v-if="!results.length && !loading" description="暂无推荐，请输入有效的景点 ID 或先构建多模态模型" />

    <div v-else class="card-grid">
      <div v-for="item in results" :key="item.poiId" class="poi-card">
        <div class="cover" :style="{ backgroundImage: `url(${item.coverImageUrl || fallbackImage})` }"></div>
        <div class="meta">
          <div class="title-row">
            <h3>{{ item.poiName }}</h3>
            <el-tag size="mini" v-if="item.sightLevelStr">{{ item.sightLevelStr }}</el-tag>
          </div>
          <p class="desc">
            {{ (item.shortFeatures && item.shortFeatures.join(' / ')) || '暂无介绍' }}
          </p>
          <div class="info">
            <span><strong>价格：</strong>{{ formatPrice(item.price) }}</span>
            <span><strong>热度：</strong>{{ item.heatScore ?? '--' }}</span>
            <span><strong>评分：</strong>{{ item.commentScore ?? '--' }}</span>
          </div>
          <div class="tags">
            <el-tag
              v-for="tag in (item.tagNameList || []).slice(0, 4)"
              :key="tag"
              size="mini"
              effect="plain"
            >
              {{ tag }}
            </el-tag>
          </div>
          <div class="actions">
            <el-button type="primary" plain size="mini" @click="goDetail(item.poiId)">查看详情</el-button>
            <el-link :href="item.detailUrl" target="_blank" type="primary">官网</el-link>
          </div>
        </div>
      </div>
    </div>

    <el-card class="info-card" shadow="never">
      <h3>算法简介</h3>
      <p>
        多模态内容推荐会将 POI 的封面图、文案、标签同时送入 TensorFlow + CLIP 模型，分别获取图像、文本、标签 Embedding 后拼接成统一向量。再通过余弦相似度寻找最接近的景点，能够更好地捕捉视觉 + 语义的相似性。
      </p>
      <ul>
        <li>图片特征：CLIP Image Encoder，默认使用 TF-Hub 的 `clip-vit-base-patch16`。</li>
        <li>文本特征：POI 名称 + 亮点描述 + 标签文本输入 CLIP Text Encoder。</li>
        <li>标签特征：哈希桶 one-hot 表示，可自定义长度。</li>
        <li>部署：通过 `python manage.py build_multimodal_embeddings` 离线生成向量，接口加载后实时返回结果。</li>
      </ul>
    </el-card>
  </div>
</template>

<script>
import api from '@/services/api';

export default {
  name: 'MultimodalRecommend',
  data() {
    return {
      form: {
        poiId: ''
      },
      loading: false,
      results: [],
      fallbackImage: 'https://dummyimage.com/240x160/edf2f7/606266&text=NO+IMAGE',
      trainLoading: false
    };
  },
  methods: {
    async fetchRecommend() {
      if (!this.form.poiId) {
        this.$message.warning('请输入景点 ID');
        return;
      }
      this.loading = true;
      try {
        const { data } = await api.get('/recommend/multimodal/', {
          params: { poi_id: this.form.poiId }
        });
        this.results = data.results || [];
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '获取推荐失败');
      } finally {
        this.loading = false;
      }
    },
    async trainModel() {
      this.trainLoading = true;
      try {
        const { data } = await api.post('/recommend/train/multimodal/');
        this.$message.success(data.detail || '多模态向量构建完成');
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '多模态模型构建失败');
      } finally {
        this.trainLoading = false;
      }
    },
    formatPrice(value) {
      if (value === null || value === undefined) return '¥--';
      if (Number(value) === 0) return '免费';
      return `¥${Number(value).toFixed(0)}`;
    },
    goDetail(poiId) {
      this.$router.push({ name: 'attraction-detail', params: { poiId } });
    }
  }
};
</script>

<style scoped lang="scss">
.mm-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 16px;
}

.poi-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.cover {
  height: 180px;
  background-size: cover;
  background-position: center;
}

.meta {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  h3 {
    margin: 0;
    font-size: 18px;
  }
}

.desc {
  margin: 0;
  color: #606266;
  min-height: 40px;
}

.info {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  font-size: 13px;
  color: #606266;
}

.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 4px;
}

.info-card {
  margin-top: 24px;
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  h3 {
    margin-top: 0;
  }
  ul {
    padding-left: 20px;
    margin-bottom: 0;
  }
}
</style>

