<template>
  <div class="cf-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>智能推荐（UserCF）</h2>
        <p>基于用户浏览/收藏/评论记录的协同过滤，为你推荐可能喜欢的景点</p>
      </div>
      <div class="info">
        当前登录用户：{{ currentUser?.nickname || currentUser?.username || '--' }}
        <el-button type="primary" @click="fetchRecommend" :loading="loading" style="margin-left: 12px">
          刷新推荐
        </el-button>
        <el-button
          type="warning"
          plain
          size="mini"
          @click="trainModel"
          :loading="trainLoading"
          style="margin-left: 8px"
        >
          重新训练模型
        </el-button>
      </div>
    </div>

    <el-empty v-if="!results.length && !loading" description="暂无推荐，请先训练模型或增加行为数据" />

    <div v-else class="card-grid">
      <div v-for="item in results" :key="item.poiId" class="poi-card">
        <div class="cover" :style="{ backgroundImage: `url(${item.coverImageUrl || fallbackImage})` }"></div>
        <div class="meta">
          <div class="title-row">
            <h3>{{ item.poiName }}</h3>
            <el-tag size="mini" v-if="item.sightLevelStr">{{ item.sightLevelStr }}</el-tag>
          </div>
          <p class="desc">
            {{ (item.shortFeatures && item.shortFeatures.join(' / ')) || '暂无简介' }}
          </p>
          <div class="info">
            <span><strong>价格：</strong>{{ formatPrice(item.price) }}</span>
            <span><strong>热度：</strong>{{ item.heatScore ?? '--' }}</span>
            <span><strong>评分：</strong>{{ item.commentScore ?? '--' }}</span>
          </div>
          <div class="tags">
            <el-tag
              v-for="tag in (item.tagNameList || []).slice(0, 4)"
              :key="tag"
              size="mini"
              effect="plain"
            >
              {{ tag }}
            </el-tag>
          </div>
          <div class="actions">
            <el-button type="primary" plain size="mini" @click="goDetail(item.poiId)">查看详情</el-button>
            <el-link :href="item.detailUrl" target="_blank" type="primary">官网</el-link>
          </div>
        </div>
      </div>
    </div>

    <el-card class="info-card" shadow="never">
      <h3>算法说明</h3>
      <p>
        UserCF（User-based Collaborative Filtering）通过“看过相同景点的用户”之间的相似度，推断你可能喜欢的景点。
        我们会收集点击、详情浏览、收藏、评论等行为数据，并赋予不同权重，训练 TensorFlow Embedding 模型得到用户与景点的潜在向量表示。
      </p>
      <ul>
        <li>行为权重示例：点击 1.0、浏览 0.8、收藏 1.5、评论 2.0。</li>
        <li>训练方式：对用户/景点建立 Embedding，使用正负样本做二分类训练，生成相似度矩阵。</li>
        <li>上线策略：每日或每周离线训练，结果存储为向量文件，接口读取后快速完成推荐。</li>
      </ul>
    </el-card>
  </div>
</template>

<script>
import api from '@/services/api';
import { mapState } from 'vuex';

export default {
  name: 'UserCF',
  data() {
    return {
      loading: false,
      results: [],
      fallbackImage: 'https://dummyimage.com/240x160/edf2f7/606266&text=NO+IMAGE',
      retryTimer: null,
      trainLoading: false
    };
  },
  computed: {
    ...mapState(['currentUser'])
  },
  created() {
    this.tryFetch();
  },
  methods: {
    tryFetch() {
      if (this.currentUser?.id) {
        this.fetchRecommend();
        return;
      }
      this.retryTimer = setTimeout(this.tryFetch, 1000);
    },
    async fetchRecommend() {
      if (!this.currentUser?.id) {
        this.$message.warning('尚未获取到用户信息，请登录或稍后重试');
        return;
      }
      this.loading = true;
      try {
        const { data } = await api.get('/recommend/user-cf/', {
          params: { user_id: this.currentUser.id }
        });
        this.results = data.results || [];
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '获取推荐失败');
      } finally {
        this.loading = false;
      }
    },
    async trainModel() {
      this.trainLoading = true;
      try {
        const { data } = await api.post('/recommend/train/user-cf/');
        this.$message.success(data.detail || 'UserCF 模型训练完成');
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '模型训练失败');
      } finally {
        this.trainLoading = false;
      }
    },
    formatPrice(value) {
      if (value === null || value === undefined) return '¥--';
      if (Number(value) === 0) return '免费';
      return `¥${Number(value).toFixed(0)}`;
    },
    goDetail(poiId) {
      this.$router.push({ name: 'attraction-detail', params: { poiId } });
    }
  }
};
</script>

<style scoped lang="scss">
.cf-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
  .info {
    display: flex;
    align-items: center;
    font-size: 14px;
    color: #303133;
  }
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
  gap: 16px;
}

.poi-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.cover {
  height: 180px;
  background-size: cover;
  background-position: center;
}

.meta {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.title-row {
  display: flex;
  align-items: center;
  gap: 8px;
  h3 {
    margin: 0;
    font-size: 18px;
  }
}

.desc {
  margin: 0;
  color: #606266;
  min-height: 40px;
}

.info {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  font-size: 13px;
  color: #606266;
}

.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 4px;
}

.info-card {
  margin-top: 24px;
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  h3 {
    margin-top: 0;
  }
  ul {
    padding-left: 20px;
    margin-bottom: 0;
  }
}
</style>

