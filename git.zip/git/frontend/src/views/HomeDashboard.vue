<template>
  <div class="home-dashboard" v-loading="loadingIndex">
    <div class="hero">
      <div>
        <h2>系统仪表盘</h2>
        <p>基于 Hive + PyHive 的轻量级运营分析面板</p>
      </div>
      <el-button type="primary" @click="$router.push('/big-screen')">
        打开运营大屏
      </el-button>
    </div>

    <el-row :gutter="16" class="card-row">
      <el-col :span="6" v-for="card in metricList" :key="card.label">
        <div class="card">
          <p class="label">{{ card.label }}</p>
          <p class="value">{{ card.value }}</p>
        </div>
      </el-col>
    </el-row>

    <div class="chart-grid">
      <div class="chart-panel" ref="cityChart"></div>
      <div class="chart-panel" ref="priceChart"></div>
      <div class="chart-panel" ref="trendChart"></div>
      <div class="chart-panel tags" ref="tagChart"></div>
    </div>

    <div class="featured" style="margin-top: 0">
      <div class="panel-head">
        <h3>精选景点</h3>
      </div>
      <div class="featured-grid">
        <div class="featured-card" v-for="item in featuredList" :key="item.poiId">
          <div class="img" :style="{ backgroundImage: `url(${item.imageUrl || fallbackImage})` }"></div>
          <div class="meta">
            <div class="title-row">
              <span class="name">{{ item.name }}</span>
              <span class="city">{{ item.city || '未知' }}</span>
            </div>
            <div class="badges">
              <el-tag size="mini" effect="plain">评分 {{ item.score ?? '--' }}</el-tag>
              <el-tag size="mini" type="success" effect="plain">热度 {{ item.heatScore ?? '--' }}</el-tag>
            </div>
            <p class="desc">{{ item.desc || '暂无介绍' }}</p>
            <div class="actions">
              <span class="price">{{ formatPrice(item.price) }}</span>
              <el-button type="text" :disabled="!item.detailUrl" :href="item.detailUrl" target="_blank">
                <a style="color:#409eff;text-decoration: none" :href="item.detailUrl">查看详情</a>
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import 'echarts-wordcloud';
import { mapState } from 'vuex';

export default {
  name: 'HomeDashboard',
  data() {
    return {
      charts: {},
      fallbackImage: 'https://dummyimage.com/200x120/edf2f7/606266&text=NO+IMAGE',
    };
  },
  computed: {
    ...mapState(['indexDashboard', 'loadingIndex']),
    metricList() {
      const cards = this.indexDashboard?.cards || {};
      return [
        { label: '付费景点', value: cards.paidAttractions ?? '--' },
        { label: '免费景点', value: cards.freeAttractions ?? '--' },
        { label: '平均票价', value: cards.avgPrice ? `¥${cards.avgPrice}` : '--' },
        { label: '平均热度', value: cards.avgHeat ?? '--' },
      ];
    },
    featuredList() {
      return this.indexDashboard?.featuredList || [];
    },
  },
  watch: {
    indexDashboard: {
      handler() {
        if (this.indexDashboard) {
          this.renderCharts();
        }
      },
      immediate: true,
    },
  },
  mounted() {
    this.$store.dispatch('fetchIndexDashboard');
    window.addEventListener('resize', this.resizeCharts);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resizeCharts);
    Object.values(this.charts).forEach(chart => chart?.dispose());
  },
  methods: {
    getChart(refName) {
      const el = this.$refs[refName];
      if (!el) return null;
      if (!this.charts[refName]) {
        this.charts[refName] = echarts.init(el, null, { renderer: 'canvas' });
      }
      return this.charts[refName];
    },
    renderCharts() {
      this.renderCity();
      this.renderPrice();
      this.renderCategory();
      this.renderTrend();
      this.renderTags();
    },
    resizeCharts() {
      Object.values(this.charts).forEach(chart => chart?.resize());
    },
    renderCity() {
      const chart = this.getChart('cityChart');
      if (!chart) return;
      const data = this.indexDashboard?.cityOverview || [];
      if (!data.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        title: { text: '价格层级分布', left: 'center' },
        tooltip: { trigger: 'axis' },
        legend: { data: ['景点数', '均分'], bottom: 0 },
        xAxis: { type: 'category', data: data.map(item => item.bucket) },
        yAxis: [
          { type: 'value', name: '景点数' },
          { type: 'value', name: '均分', min: 0, max: 5 },
        ],
        grid: { left: 50, right: 30, bottom: 60 },
        series: [
          { name: '景点数', type: 'bar', data: data.map(item => item.count), color: '#409EFF' },
          { name: '均分', type: 'line', yAxisIndex: 1, data: data.map(item => item.avgScore), color: '#F7BA2A' },
        ],
      });
    },
    renderPrice() {
      const chart = this.getChart('priceChart');
      if (!chart) return;
      const data = this.indexDashboard?.priceTrend || [];
      if (!data.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        title: { text: '均价 vs. 热度走势', left: 'center' },
        tooltip: { trigger: 'axis' },
        legend: { data: ['平均热度', '平均票价'], bottom: 0 },
        xAxis: { type: 'category', data: data.map(item => item.date) },
        yAxis: [
          { type: 'value', name: '平均热度', min: 0 },
          { type: 'value', name: '平均票价', min: 0 },
        ],
        grid: { left: 50, right: 30, bottom: 60 },
        series: [
          { name: '平均热度', type: 'line', data: data.map(item => item.avgHeat), smooth: true, color: '#E6A23C' },
          { name: '平均票价', type: 'line', yAxisIndex: 1, data: data.map(item => item.avgPrice), smooth: true, color: '#67C23A' },
        ],
      });
    },
    renderCategory() {
      const chart = this.getChart('categoryChart');
      if (!chart) return;
      const data = this.indexDashboard?.categoryMatrix || [];
      if (!data.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        title: { text: '品类构成', left: 'center' },
        tooltip: { trigger: 'item' },
        series: [
          {
            type: 'pie',
            radius: '60%',
            data: data.map(item => ({ name: item.category, value: item.value })),
          },
        ],
      });
    },
    renderTrend() {
      const chart = this.getChart('trendChart');
      if (!chart) return;
      const data = this.indexDashboard?.recentTrend || [];
      if (!data.length) {
        chart.clear();
        return;
      }
      const grouped = {};
      data.forEach(item => {
        if (!grouped[item.city]) {
          grouped[item.city] = [];
        }
        grouped[item.city].push(item);
      });
      const cities = Object.keys(grouped);
      const avgScore = cities.map(city => {
        const arr = grouped[city];
        const sum = arr.reduce((acc, cur) => acc + (Number(cur.commentScore) || 0), 0);
        return arr.length ? (sum / arr.length) : 0;
      });
      const totalComments = cities.map(city => grouped[city].reduce((acc, cur) => acc + (Number(cur.commentCount) || 0), 0));

      chart.setOption({
        title: { text: '城市口碑与评论量', left: 'center' },
        tooltip: { trigger: 'axis' },
        legend: { data: ['评论总量', '平均评分'], bottom: 0 },
        xAxis: { type: 'category', data: cities },
        yAxis: [
          { type: 'value', name: '评论总量' },
          { type: 'value', name: '平均评分', min: 0, max: 5 },
        ],
        grid: { left: 50, right: 30, bottom: 60 },
        series: [
          { name: '评论总量', type: 'bar', data: totalComments, color: '#F56C6C' },
          { name: '平均评分', type: 'line', yAxisIndex: 1, data: avgScore, color: '#303133' },
        ],
      });
    },
    renderTags() {
      const chart = this.getChart('tagChart');
      if (!chart) return;
      const data = this.indexDashboard?.hotTags || [];
      if (!data.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        title: { text: '热门标签', left: 'center' },
        series: [
          {
            type: 'wordCloud',
            gridSize: 4,
            sizeRange: [14, 48],
            rotationRange: [-30, 30],
            textStyle: {
              color() {
                const colors = ['#5B8FF9', '#61DDAA', '#65789B', '#F6BD16', '#7262fd'];
                return colors[Math.floor(Math.random() * colors.length)];
              },
            },
            data,
          },
        ],
      });
    },
    formatPrice(value) {
      if (value === null || value === undefined) return '¥--';
      if (Number(value) === 0) return '免费';
      return `¥${Number(value).toFixed(0)}`;
    },
  },
};
</script>

<style scoped lang="scss">
.home-dashboard {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
  color: #2c3e50;
}

.hero {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #ffffff;
  padding: 16px 24px;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 24px;
  }
  p {
    margin: 0;
    color: #909399;
  }
}

.card-row .card {
  background: #ffffff;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  .label {
    color: #909399;
    margin: 0;
  }
  .value {
    font-size: 32px;
    font-weight: 600;
    margin: 8px 0 0;
  }
}

.chart-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-auto-rows: 280px;
  gap: 16px;
  margin-top: 16px;
}

.chart-panel {
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  padding: 8px;
}

.chart-panel.tags {
  grid-column: span 3;
  height: 260px;
}

.featured {
  margin-top: 24px;
  background: #ffffff;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.05);
}

.panel-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  h3 {
    margin: 0;
  }
}

.featured-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 16px;
}

.featured-card {
  display: flex;
  background: #f9fafc;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.05);
}

.img {
  width: 140px;
  background-size: cover;
  background-position: center;
}

.meta {
  padding: 12px;
  display: flex;
  flex-direction: column;
  flex: 1;
}

.title-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
  .name {
    font-weight: 600;
  }
  .city {
    color: #909399;
    font-size: 12px;
  }
}

.badges {
  display: flex;
  gap: 8px;
  margin-bottom: 6px;
}

.desc {
  flex: 1;
  color: #606266;
  font-size: 13px;
  margin: 0 0 6px;
}

.actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .price {
    font-weight: 600;
    color: #409eff;
  }
}
</style>

