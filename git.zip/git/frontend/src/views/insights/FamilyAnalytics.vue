<template>
  <div class="insight-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>亲子/家庭偏好分析</h2>
        <p>聚焦亲子标签景点，观察区域分布、口碑热度与预订策略</p>
      </div>
      <div class="info">
        <span class="dot"></span>
        数据量：{{ (payload?.district || []).length }} 个重点区域
      </div>
    </div>

    <div class="chart-grid">
      <EChartCard title="亲子热门标签" :options="tagOption" height="300px" />
      <EChartCard title="区域分布" :options="districtOption" height="300px" />
      <EChartCard title="景区等级占比" :options="levelOption" height="300px" />
      <EChartCard title="热度段位" :options="heatOption" height="300px" />
      <EChartCard title="预订策略偏好" :options="bookingOption" height="300px" />
    </div>
  </div>
</template>

<script>
import api from '@/services/api';
import EChartCard from '@/components/EChartCard.vue';

export default {
  name: 'FamilyAnalytics',
  components: { EChartCard },
  data() {
    return {
      loading: false,
      payload: {}
    };
  },
  computed: {
    tags() {
      return this.payload.tags || [];
    },
    district() {
      return this.payload.district || [];
    },
    levels() {
      return this.payload.levels || [];
    },
    heat() {
      return this.payload.heat || [];
    },
    booking() {
      return this.payload.booking || [];
    },
    tagOption() {
      if (!this.tags.length) return {};
      return {
        series: [
          {
            type: 'wordCloud',
            gridSize: 4,
            sizeRange: [16, 50],
            rotationRange: [-20, 20],
            textStyle: {
              color() {
                const colors = ['#5B8FF9', '#61DDAA', '#65789B', '#F6BD16', '#F56C6C'];
                return colors[Math.floor(Math.random() * colors.length)];
              }
            },
            data: this.tags.map(item => ({ name: item.tag, value: item.value }))
          }
        ]
      };
    },
    districtOption() {
      if (!this.district.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        xAxis: { type: 'value', name: '景点数' },
        yAxis: { type: 'category', data: this.district.map(item => item.district), inverse: true },
        series: [
          {
            type: 'bar',
            data: this.district.map(item => item.count),
            itemStyle: { color: '#67C23A' }
          }
        ]
      };
    },
    levelOption() {
      if (!this.levels.length) return {};
      return {
        tooltip: { trigger: 'item' },
        series: [
          {
            type: 'pie',
            radius: ['45%', '70%'],
            data: this.levels.map(item => ({ name: item.sightLevelStr || '其他', value: item.count })),
            label: { formatter: '{b}: {d}%' }
          }
        ]
      };
    },
    heatOption() {
      if (!this.heat.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        xAxis: { type: 'category', data: this.heat.map(item => item.bucket) },
        yAxis: [
          { type: 'value', name: '景点数' },
          { type: 'value', name: '平均热度', min: 0, max: 10 }
        ],
        legend: { bottom: 0, data: ['景点数', '平均热度'] },
        series: [
          { name: '景点数', type: 'bar', data: this.heat.map(item => item.count), itemStyle: { color: '#409EFF' } },
          {
            name: '平均热度',
            type: 'line',
            yAxisIndex: 1,
            data: this.heat.map(item => Number(item.avgHeat || 0).toFixed(2)),
            itemStyle: { color: '#E6A23C' }
          }
        ]
      };
    },
    bookingOption() {
      if (!this.booking.length) return {};
      return {
        tooltip: { trigger: 'item' },
        series: [
          {
            type: 'pie',
            radius: '60%',
            data: this.booking.map(item => ({ name: item.name || '未知', value: item.count }))
          }
        ]
      };
    }
  },
  created() {
    this.fetchData();
  },
  methods: {
    async fetchData() {
      this.loading = true;
      try {
        const { data } = await api.get('/dashboard/fore/family/');
        this.payload = data || {};
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '加载数据失败');
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.insight-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
  .info {
    display: flex;
    align-items: center;
    font-size: 13px;
    color: #909399;
    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #f56c6c;
      margin-right: 6px;
    }
  }
}



.chart-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-evenly;

}
.chart-grid .chart-card{
  width: 900px;
  margin-bottom: 15px;
}
</style>

