<template>
  <div class="insight-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>票价与折扣分析</h2>
        <p>洞察票价区间、折扣策略与口碑表现，辅助定价优选</p>
      </div>
      <el-button type="primary" icon="el-icon-refresh" @click="fetchData">刷新数据</el-button>
    </div>

    <div class="chart-grid">
      <EChartCard title="票价区间分布" :options="distributionOption" height="300px" />
      <EChartCard title="折扣力度层级" :options="discountOption" height="300px" />
      <EChartCard title="价格 vs 评分散点" :options="scatterOption" height="300px" />
      <EChartCard title="免费 / 付费对比" :options="paidOption" height="300px" />
    </div>

    <el-card class="table-card" shadow="never">
      <div class="panel-head">
        <h3>高价位景点 TOP10</h3>
      </div>
      <el-table :data="topList" stripe border>
        <el-table-column label="景点" prop="poiName" min-width="180" show-overflow-tooltip />
        <el-table-column label="票价" prop="price" width="100">
          <template slot-scope="{ row }">
            {{ formatPrice(row.price) }}
          </template>
        </el-table-column>
        <el-table-column label="门市价" prop="marketPrice" width="120">
          <template slot-scope="{ row }">
            {{ formatPrice(row.marketPrice) }}
          </template>
        </el-table-column>
        <el-table-column label="热度" prop="heatScore" width="100" />
        <el-table-column label="评分" prop="commentScore" width="100" />
      </el-table>
    </el-card>
  </div>
</template>

<script>
import api from '@/services/api';
import EChartCard from '@/components/EChartCard.vue';

export default {
  name: 'PriceAnalytics',
  components: { EChartCard },
  data() {
    return {
      loading: false,
      payload: {}
    };
  },
  computed: {
    distribution() {
      return this.payload.distribution || [];
    },
    discount() {
      return this.payload.discount || [];
    },
    scatter() {
      return this.payload.scatter || [];
    },
    paidCompare() {
      return this.payload.paidCompare || [];
    },
    topList() {
      return this.payload.topList || [];
    },
    distributionOption() {
      if (!this.distribution.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        xAxis: { type: 'category', data: this.distribution.map(item => item.bucket) },
        yAxis: { type: 'value', name: '景点数量' },
        series: [
          {
            type: 'bar',
            data: this.distribution.map(item => item.count),
            itemStyle: { color: '#5B8FF9' }
          }
        ]
      };
    },
    discountOption() {
      if (!this.discount.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0, data: ['景点数', '平均优惠'] },
        xAxis: { type: 'category', data: this.discount.map(item => item.bucket) },
        yAxis: [
          { type: 'value', name: '景点数' },
          { type: 'value', name: '平均优惠', min: 0 }
        ],
        series: [
          {
            name: '景点数',
            type: 'line',
            data: this.discount.map(item => item.count),
            smooth: true,
            itemStyle: { color: '#E6A23C' }
          },
          {
            name: '平均优惠',
            type: 'bar',
            yAxisIndex: 1,
            data: this.discount.map(item => Number(item.avgDiscount || 0).toFixed(0)),
            itemStyle: { color: '#67C23A' }
          }
        ]
      };
    },
    scatterOption() {
      if (!this.scatter.length) return {};
      return {
        tooltip: {
          formatter: params => `票价：¥${params.data[0].toFixed(0)}<br/>评分：${params.data[1].toFixed(2)}`
        },
        xAxis: { type: 'value', name: '票价', min: 0 },
        yAxis: { type: 'value', name: '评分', min: 0, max: 5 },
        series: [
          {
            type: 'scatter',
            symbolSize: 10,
            data: this.scatter.map(item => [item.price || 0, item.commentScore || 0]),
            itemStyle: { color: '#F56C6C' }
          }
        ]
      };
    },
    paidOption() {
      if (!this.paidCompare.length) return {};
      return {
        legend: { bottom: 0, data: this.paidCompare.map(item => item.label) },
        tooltip: { trigger: 'item' },
        series: [
          {
            type: 'pie',
            radius: ['45%', '70%'],
            data: this.paidCompare.map(item => ({ name: item.label, value: item.count })),
            label: { formatter: '{b}\n{d}%' }
          }
        ]
      };
    }
  },
  created() {
    this.fetchData();
  },
  methods: {
    async fetchData() {
      this.loading = true;
      try {
        const { data } = await api.get('/dashboard/fore/price/');
        this.payload = data || {};
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '加载数据失败');
      } finally {
        this.loading = false;
      }
    },
    formatPrice(value) {
      if (value === null || value === undefined) return '¥--';
      if (Number(value) === 0) return '免费';
      return `¥${Number(value).toFixed(0)}`;
    }
  }
};
</script>

<style scoped lang="scss">
.insight-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
}

.chart-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 16px;
  margin-bottom: 16px;
}

.table-card {
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
}

.panel-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  h3 {
    margin: 0;
  }
}
</style>

