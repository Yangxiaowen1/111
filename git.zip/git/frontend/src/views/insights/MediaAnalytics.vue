<template>
  <div class="insight-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>媒介曝光与体验洞察</h2>
        <p>分析视频素材、活动热点、距离与价格标签的表现</p>
      </div>
      <div class="info">
        <i class="el-icon-video-camera"></i>
        视频素材覆盖率：{{ videoCoverage }}
      </div>
    </div>

    <div class="chart-grid">
      <EChartCard title="视频素材对比" :options="videoOption" height="300px" />
      <EChartCard title="距离市中心分布" :options="distanceOption" height="300px" />
      <EChartCard title="开放状态概览" :options="openingOption" height="300px" />
      <EChartCard title="热点活动词云" :options="eventOption" height="300px" />
      <EChartCard title="价格标签热度" :options="priceTagOption" height="300px" />
    </div>
  </div>
</template>

<script>
import api from '@/services/api';
import EChartCard from '@/components/EChartCard.vue';

export default {
  name: 'MediaAnalytics',
  components: { EChartCard },
  data() {
    return {
      loading: false,
      payload: {}
    };
  },
  computed: {
    video() {
      return this.payload.video || [];
    },
    distance() {
      return this.payload.distance || [];
    },
    opening() {
      return this.payload.opening || [];
    },
    events() {
      return this.payload.events || [];
    },
    priceTag() {
      return this.payload.priceTag || [];
    },
    videoCoverage() {
      const videoItem = this.video.find(item => item.label === '可看视频');
      const total = this.video.reduce((sum, item) => sum + (item.count || 0), 0);
      if (!total) return '--';
      const ratio = ((videoItem?.count || 0) / total) * 100;
      return `${ratio.toFixed(1)}%`;
    },
    videoOption() {
      if (!this.video.length) return {};
      return {
        tooltip: { trigger: 'item' },
        series: [
          {
            type: 'pie',
            radius: ['45%', '70%'],
            data: this.video.map(item => ({ name: item.label, value: item.count })),
            label: { formatter: '{b}\n{d}%' }
          }
        ]
      };
    },
    distanceOption() {
      if (!this.distance.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0, data: ['景点数', '平均热度'] },
        xAxis: { type: 'category', data: this.distance.map(item => item.bucket) },
        yAxis: [
          { type: 'value', name: '景点数' },
          { type: 'value', name: '平均热度', min: 0, max: 10 }
        ],
        series: [
          { name: '景点数', type: 'bar', data: this.distance.map(item => item.count), itemStyle: { color: '#5B8FF9' } },
          {
            name: '平均热度',
            type: 'line',
            yAxisIndex: 1,
            data: this.distance.map(item => Number(item.avgHeat || 0).toFixed(2)),
            itemStyle: { color: '#F6BD16' }
          }
        ]
      };
    },
    openingOption() {
      if (!this.opening.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        xAxis: { type: 'category', data: this.opening.map(item => item.status) },
        yAxis: { type: 'value', name: '景点数' },
        series: [
          {
            type: 'bar',
            data: this.opening.map(item => item.count),
            itemStyle: { color: '#61DDAA' }
          }
        ]
      };
    },
    eventOption() {
      if (!this.events.length) return {};
      return {
        series: [
          {
            type: 'wordCloud',
            sizeRange: [14, 48],
            rotationRange: [-45, 45],
            gridSize: 6,
            textStyle: {
              color() {
                const colors = ['#5B8FF9', '#61DDAA', '#F6BD16', '#7262fd', '#F56C6C'];
                return colors[Math.floor(Math.random() * colors.length)];
              }
            },
            data: this.events.map(item => ({ name: item.name, value: item.count }))
          }
        ]
      };
    },
    priceTagOption() {
      if (!this.priceTag.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        xAxis: { type: 'category', data: this.priceTag.map(item => item.name) },
        yAxis: { type: 'value', name: '景点数' },
        series: [
          {
            type: 'line',
            smooth: true,
            symbol: 'circle',
            data: this.priceTag.map(item => item.count),
            itemStyle: { color: '#F56C6C' },
            areaStyle: { color: 'rgba(245,108,108,0.2)' }
          }
        ]
      };
    }
  },
  created() {
    this.fetchData();
  },
  methods: {
    async fetchData() {
      this.loading = true;
      try {
        const { data } = await api.get('/dashboard/fore/media/');
        this.payload = data || {};
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '加载数据失败');
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.insight-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
  .info {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #606266;
    font-size: 14px;
  }
}

.chart-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-evenly;

}
.chart-grid .chart-card{
  width: 900px;
  margin-bottom: 15px;
}
</style>

