<template>
  <div class="insight-page" v-loading="loading">
    <div class="hero">
      <div>
        <h2>条件筛选洞察</h2>
        <p>根据城市、景区等级、标签等条件拆解核心指标表现</p>
      </div>
      <div class="info">
        <span class="dot"></span>
        最新更新时间：{{ payload.generatedAt ? formatTime(payload.generatedAt) : '--' }}
      </div>
    </div>

    <el-card class="filter-card" shadow="never">
      <el-form :inline="true" label-width="80px">
        <el-form-item label="城市关键">
          <el-input v-model.trim="filters.city" placeholder="如：上海、杭州" clearable style="width: 240px" />
        </el-form-item>
        <el-form-item label="景区等级">
          <el-select v-model="filters.level" placeholder="全部" clearable style="width: 160px">
            <el-option label="5A" value="5A" />
            <el-option label="4A" value="4A" />
            <el-option label="3A" value="3A" />
            <el-option label="其他" value="其他" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">应用筛选</el-button>
          <el-button @click="resetFilter">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <div class="chart-grid">
      <EChartCard title="城市价格-热度分布" :options="cityOption" height="320px" />
      <EChartCard title="景区等级口碑对比" :options="levelOption" height="320px" />
      <EChartCard title="热门标签词云" :options="tagOption" height="320px" />
      <EChartCard title="预订政策偏好" :options="bookingOption" height="320px" />
      <EChartCard title="价格段口碑表现" :options="priceOption" height="320px" />
    </div>
  </div>
</template>

<script>
import api from '@/services/api';
import EChartCard from '@/components/EChartCard.vue';

export default {
  name: 'ConditionAnalytics',
  components: { EChartCard },
  data() {
    return {
      loading: false,
      payload: {},
      filters: {
        city: '',
        level: ''
      },
      appliedFilters: {
        city: '',
        level: ''
      }
    };
  },
  computed: {
    cityData() {
      const list = this.payload.cityInsight || [];
      const keyword = (this.appliedFilters.city || '').toLowerCase();
      if (!keyword) return list;
      return list.filter(item => (item.city || '').toLowerCase().includes(keyword));
    },
    levelData() {
      const list = this.payload.levelBreakdown || [];
      const level = this.appliedFilters.level;
      if (!level) return list;
      return list.filter(item => (item.sightLevelStr || '其他') === level);
    },
    tagData() {
      return (this.payload.tagHot || []).map(item => ({
        name: item.tag,
        value: item.value,
        avgHeat: item.avgHeat
      }));
    },
    bookingData() {
      return this.payload.bookingStats || [];
    },
    priceData() {
      return this.payload.priceBuckets || [];
    },
    cityOption() {
      if (!this.cityData.length) return {};
      return {
        tooltip: {
          trigger: 'item',
          formatter: params => {
            const data = params.data;
            return `${data.city}<br/>平均票价：¥${data.avgPrice?.toFixed(0) || '--'}<br/>平均热度：${(data.avgHeat || 0).toFixed(2)}<br/>景点数：${data.attractionCount}`;
          }
        },
        xAxis: { name: '平均票价', type: 'value' },
        yAxis: { name: '平均热度', type: 'value', min: 0, max: 10 },
        series: [
          {
            type: 'scatter',
            data: this.cityData.map(item => ({
              value: [item.avgPrice || 0, item.avgHeat || 0, item.attractionCount],
              city: item.city,
              avgPrice: item.avgPrice,
              avgHeat: item.avgHeat,
              attractionCount: item.attractionCount,
              symbolSize: Math.max(10, Math.min(60, (item.attractionCount || 0) / 5))
            })),
            itemStyle: { color: '#5B8FF9' }
          }
        ]
      };
    },
    levelOption() {
      if (!this.levelData.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0, data: ['景点数', '平均评分'] },
        xAxis: { type: 'category', data: this.levelData.map(item => item.sightLevelStr || '其他') },
        yAxis: [
          { type: 'value', name: '景点数' },
          { type: 'value', name: '平均评分', min: 0, max: 5 }
        ],
        series: [
          {
            name: '景点数',
            type: 'bar',
            data: this.levelData.map(item => item.count),
            itemStyle: { color: '#409EFF' },
            barWidth: 30
          },
          {
            name: '平均评分',
            type: 'line',
            yAxisIndex: 1,
            data: this.levelData.map(item => Number(item.avgScore || 0).toFixed(2)),
            itemStyle: { color: '#E6A23C' }
          }
        ]
      };
    },
    tagOption() {
      if (!this.tagData.length) return {};
      return {
        series: [
          {
            type: 'wordCloud',
            gridSize: 4,
            sizeRange: [14, 48],
            rotationRange: [-30, 30],
            textStyle: {
              color() {
                const colors = ['#5B8FF9', '#61DDAA', '#65789B', '#F6BD16', '#F56C6C'];
                return colors[Math.floor(Math.random() * colors.length)];
              }
            },
            data: this.tagData
          }
        ]
      };
    },
    bookingOption() {
      if (!this.bookingData.length) return {};
      return {
        tooltip: { trigger: 'item' },
        series: [
          {
            type: 'pie',
            radius: ['40%', '70%'],
            data: this.bookingData.map(item => ({ name: item.name || '未知', value: item.count })),
            label: { formatter: '{b}\n{d}%' }
          }
        ]
      };
    },
    priceOption() {
      if (!this.priceData.length) return {};
      return {
        tooltip: { trigger: 'axis' },
        legend: { bottom: 0, data: ['景点数', '均分'] },
        xAxis: { type: 'category', data: this.priceData.map(item => item.priceBucket) },
        yAxis: [
          { type: 'value', name: '景点数' },
          { type: 'value', name: '均分', min: 0, max: 5 }
        ],
        series: [
          {
            name: '景点数',
            type: 'bar',
            data: this.priceData.map(item => item.count),
            itemStyle: { color: '#67C23A' }
          },
          {
            name: '均分',
            type: 'line',
            yAxisIndex: 1,
            data: this.priceData.map(item => Number(item.avgScore || 0).toFixed(2)),
            itemStyle: { color: '#909399' }
          }
        ]
      };
    }
  },
  created() {
    this.fetchData();
  },
  methods: {
    async fetchData() {
      this.loading = true;
      try {
        const { data } = await api.get('/dashboard/fore/condition/');
        this.payload = data || {};
        this.appliedFilters = { ...this.filters };
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '加载数据失败');
      } finally {
        this.loading = false;
      }
    },
    handleSearch() {
      this.appliedFilters = { ...this.filters };
    },
    resetFilter() {
      this.filters = { city: '', level: '' };
      this.handleSearch();
    },
    formatTime(ts) {
      return new Date(ts).toLocaleString();
    }
  }
};
</script>

<style scoped lang="scss">
.insight-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.hero {
  background: #fff;
  border-radius: 12px;
  padding: 18px 24px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  h2 {
    margin: 0 0 4px;
    font-size: 22px;
  }
  p {
    margin: 0;
    color: #909399;
  }
  .info {
    display: flex;
    align-items: center;
    font-size: 13px;
    color: #909399;
    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #67c23a;
      margin-right: 6px;
    }
  }
}

.filter-card {
  margin-bottom: 16px;
  border: none;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
}

.chart-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-evenly;

}
.chart-grid .chart-card{
  width: 900px;
  margin-bottom: 15px;
}
</style>

