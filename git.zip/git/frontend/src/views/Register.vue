<template>
  <div class="auth-page">
    <el-card class="auth-card">
      <div slot="header" class="card-header">
        <span>注册账户</span>
        <small>快速开启数据大屏体验</small>
      </div>
      <el-form :model="form" :rules="rules" ref="form" label-position="top">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="form.email" placeholder="可选，接收通知"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="form.password" type="password" placeholder="至少 6 位数字+字母"></el-input>
        </el-form-item>
        <el-button type="primary" class="btn" :loading="loading" @click="handleRegister">注册并登录</el-button>
        <el-button type="text" @click="$router.push('/login')">已有账号？直接登录</el-button>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'Register',
  data() {
    return {
      loading: false,
      form: {
        username: '',
        email: '',
        password: ''
      },
      rules: {
        username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        email: [{ type: 'email', message: '邮箱格式不正确', trigger: 'blur', required: false }]
      }
    };
  },
  methods: {
    handleRegister() {
      this.$refs.form.validate(async valid => {
        if (!valid) return;
        this.loading = true;
        try {
          await this.$store.dispatch('register', this.form);
          await this.$store.dispatch('fetchDashboardData');
          this.$router.push('/big-screen');
        } catch (error) {
          this.$message.error(error.response?.data?.detail || '注册失败');
        } finally {
          this.loading = false;
        }
      });
    }
  }
};
</script>

<style scoped lang="scss">
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #ffffff, #d9ecff);
}

.auth-card {
  width: 450px;
}

.card-header {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
  span {
    font-size: 20px;
    font-weight: 600;
  }
  small {
    color: #909399;
  }
}

.btn {
  width: 100%;
  margin-top: 12px;
}
</style>

