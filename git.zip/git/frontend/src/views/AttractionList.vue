<template>
  <div class="attraction-page">
    <el-card class="filter-card" shadow="hover">
      <div slot="header" class="filter-header">
        <span>高级筛选</span>
        <small>支持关键字 / 区域 / 价格 / 标签组合查询</small>
      </div>
      <el-form :model="filters" label-width="90px" :inline="false" class="filter-form">
        <el-row :gutter="20">
          <el-col :span="6">
            <el-form-item label="关键词">
              <el-input
                v-model="filters.keyword"
                placeholder="景点名称 / 区域 / 标签"
                clearable
              />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所在城市">
              <el-input v-model="filters.district" placeholder="如：上海" clearable />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="景区等级">
              <el-select v-model="filters.sightLevel" placeholder="请选择" clearable>
                <el-option label="5A" value="5A" />
                <el-option label="4A" value="4A" />
                <el-option label="3A" value="3A" />
                <el-option label="其他" value="其他" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="标签">
              <el-input v-model="filters.tagName" placeholder="如：亲子/网红" clearable />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="6">
            <el-form-item label="最低票价">
              <el-input-number
                v-model="filters.minPrice"
                :min="0"
                :step="10"
                :value-on-clear="null"
                controls-position="right"
              />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="最高票价">
              <el-input-number
                v-model="filters.maxPrice"
                :min="0"
                :step="10"
                :value-on-clear="null"
                controls-position="right"
              />
            </el-form-item>
          </el-col>
          <el-col :span="12" class="filter-actions">
            <el-button type="primary" icon="el-icon-search" @click="handleSearch">查询</el-button>
            <el-button @click="resetFilters">重置</el-button>
          </el-col>
        </el-row>
      </el-form>
    </el-card>

    <el-card class="table-card" shadow="never">
      <div slot="header" class="table-header">
        <div>
          <span class="title">旅游 POI 数据</span>
          <small>数据来源：Hive 表 {{ hiveTable }}</small>
        </div>
        <el-button type="text" @click="openHiveDoc">Hive 数据说明</el-button>
      </div>

      <el-table
        :data="tableData"
        border
        stripe
        v-loading="loading"
        :header-cell-style="{ background: '#f5f7fa', color: '#1f2d3d' }"
      >
        <el-table-column label="封面" width="120">
          <template slot-scope="{ row }">
            <el-image
              :src="row.coverImageUrl"
              fit="cover"
              class="thumb"
              :preview-src-list="[row.coverImageUrl]"
            >
              <div slot="error" class="image-slot">
                <i class="el-icon-picture-outline" />
              </div>
            </el-image>
          </template>
        </el-table-column>
        <el-table-column label="景点信息" min-width="220">
          <template slot-scope="{ row }">
            <div class="poi-name">{{ row.poiName }}</div>
            <div class="poi-meta">
              <span>{{ row.districtName }} · {{ row.zoneName || '暂无商圈' }}</span>
              <el-tag v-if="row.sightLevelStr" size="mini" type="success">{{ row.sightLevelStr }}</el-tag>
            </div>
            <el-link v-if="row.detailUrl" type="primary" :href="row.detailUrl" target="_blank">
              查看官网
            </el-link>
          </template>
        </el-table-column>
        <el-table-column label="特色标签" min-width="200">
          <template slot-scope="{ row }">
            <el-tag
              v-for="tag in formatTags(row.tagNameList)"
              :key="tag"
              size="mini"
              effect="dark"
              class="tag-item"
            >
              {{ tag }}
            </el-tag>
            <el-tag
              v-for="feature in formatTags(row.shortFeatures)"
              :key="feature"
              size="mini"
              type="info"
              class="tag-item"
            >
              {{ feature }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="热度/评分" width="140">
          <template slot-scope="{ row }">
            <div class="stat-line">
              热度：<span class="stat-value">{{ row.heatScore || '-' }}</span>
            </div>
            <div class="stat-line">
              评分：<span class="stat-value">{{ row.commentScore || '-' }}</span>
            </div>
            <div class="stat-line">
              评论：<span class="stat-value">{{ row.commentCount || 0 }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="价格" width="120">
          <template slot-scope="{ row }">
            <div class="price">{{ formatPrice(row.price) }}</div>
            <small v-if="row.marketPrice">门市价：￥{{ row.marketPrice }}</small>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template slot-scope="{ row }">
            <el-button type="primary" size="mini" @click="viewDetail(row)">详情</el-button>
            <el-button
              size="mini"
              type="warning"
              plain
              :loading="favoriteLoading === row.poiId"
              @click="toggleFavorite(row)"
            >
              {{ row.isFavorite ? '取消收藏' : '收藏' }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          background
          layout="total, prev, pager, next, jumper"
          :total="pagination.total"
          :current-page="pagination.page"
          :page-size="pagination.pageSize"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import api from '@/services/api';

export default {
  name: 'AttractionList',
  data() {
    return {
      filters: {
        keyword: '',
        district: '',
        sightLevel: '',
        minPrice: null,
        maxPrice: null,
        tagName: ''
      },
      tableData: [],
      loading: false,
      favoriteLoading: null,
      pagination: {
        page: 1,
        pageSize: 10,
        total: 0
      },
      hiveTable: ''
    };
  },
  computed: {
    ...mapState(['currentUser']),
    userId() {
      return this.currentUser?.id;
    }
  },
  watch: {
    userId(newVal, oldVal) {
      if (newVal && newVal !== oldVal && this.tableData.length) {
        this.attachFavoriteStatus(this.tableData).then(updated => {
          this.tableData = updated;
        });
      }
    }
  },
  created() {
    this.fetchHiveMeta();
    this.fetchData();
  },
  methods: {
    async fetchHiveMeta() {
      try {
        const { data } = await api.get('/travel/hive-pointer/');
        this.hiveTable = data.hive_table;
      } catch (error) {
        console.warn('获取 Hive 信息失败', error);
      }
    },
    async fetchData() {
      this.loading = true;
      try {
        const params = this.buildQueryParams();
        const { data } = await api.get('/travel/attractions/', { params });
        const rows = data.results || [];
        this.pagination.total = data.count || 0;
        this.tableData = await this.attachFavoriteStatus(rows);
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '加载数据失败');
      } finally {
        this.loading = false;
      }
    },
    async attachFavoriteStatus(rows) {
      if (!this.userId || !rows.length) return rows.map(item => ({ ...item, isFavorite: false }));
      const tasks = rows.map(item =>
        api
          .get('/user/favorites/', {
            params: { user_id: this.userId, poi_id: item.poiId }
          })
          .then(res => ({ poiId: item.poiId, isFavorite: res.data.is_favorite }))
          .catch(() => ({ poiId: item.poiId, isFavorite: false }))
      );
      const states = await Promise.all(tasks);
      const map = states.reduce((acc, cur) => {
            acc[cur.poiId] = cur.isFavorite;
            return acc;
          }, {});
      return rows.map(item => ({
        ...item,
        isFavorite: Boolean(map[item.poiId])
      }));
    },
    handleSearch() {
      this.pagination.page = 1;
      this.fetchData();
    },
    resetFilters() {
      this.filters = {
        keyword: '',
        district: '',
        sightLevel: '',
        minPrice: null,
        maxPrice: null,
        tagName: ''
      };
      this.handleSearch();
    },
    handlePageChange(page) {
      this.pagination.page = page;
      this.fetchData();
    },
    formatTags(value) {
      if (!value) return [];
      if (Array.isArray(value)) return value.filter(Boolean);
      if (typeof value === 'string' && value.trim().startsWith('[')) {
        try {
          const parsed = JSON.parse(value);
          if (Array.isArray(parsed)) {
            return parsed.filter(Boolean);
          }
        } catch (error) {
          console.warn('tag 解析失败', error);
        }
      }
      return String(value)
        .split(/[,、;；]/)
        .map(item => item.trim())
        .filter(Boolean);
    },
    formatPrice(value) {
      if (value === null || value === undefined || value === '') return '-';
      return `￥${Number(value).toFixed(0)}`;
    },
    openHiveDoc() {
      this.$message.info('Hive 表：' + (this.hiveTable || 'dwd_attractions'));
    },
    async toggleFavorite(row) {
      if (!this.userId) {
        this.$message.warning('请先登录后再收藏');
        return;
      }
      this.favoriteLoading = row.poiId;
      try {
        const payload = {
          user_id: this.userId,
          poi_id: row.poiId,
          is_favorite: !row.isFavorite,
          scene: 'attraction_list'
        };
        const { data } = await api.post('/user/favorites/', payload);
        row.isFavorite = data.is_favorite;
        this.$message.success(row.isFavorite ? '收藏成功' : '已取消收藏');
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '操作失败');
      } finally {
        this.favoriteLoading = null;
      }
    },
    async logClick(row) {
      if (!this.userId) return;
      try {
        await api.post('/user/click/', {
          user_id: this.userId,
          poi_id: row.poiId,
          scene: 'attraction_list',
          device: 'web'
        });
      } catch (error) {
        console.warn('点击上报失败', error);
      }
    },
    buildQueryParams() {
      const params = {
        page: this.pagination.page,
        page_size: this.pagination.pageSize
      };
      Object.entries(this.filters).forEach(([key, value]) => {
        if (value === null || value === undefined || value === '') {
          return;
        }
        if (
          ['minPrice', 'maxPrice'].includes(key) &&
          (Number(value) <= 0 || Number.isNaN(Number(value)))
        ) {
          return;
        }
        params[key] = value;
      });
      return params;
    },
    viewDetail(row) {
      this.logClick(row);
      this.$router.push({ name: 'attraction-detail', params: { poiId: row.poiId } });
    }
  }
};
</script>

<style scoped lang="scss">
.attraction-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: calc(100vh - 64px);
}

.filter-card {
  margin-bottom: 20px;
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
}

.filter-header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  span {
    font-size: 16px;
    font-weight: 600;
  }
  small {
    color: #909399;
  }
}

.filter-form {
  .filter-actions {
    display: flex;
    align-items: flex-end;
  }
}

.table-card {
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
  .table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .title {
      font-size: 18px;
      font-weight: 600;
      margin-right: 12px;
    }
    small {
      color: #909399;
    }
  }
}

.thumb {
  width: 100px;
  height: 70px;
  border-radius: 4px;
}

.poi-name {
  font-size: 16px;
  font-weight: 600;
}

.poi-meta {
  font-size: 12px;
  color: #909399;
  margin: 4px 0;
  display: flex;
  align-items: center;
  gap: 6px;
}

.tag-item {
  margin: 2px;
}

.stat-line {
  font-size: 12px;
  color: #909399;
  .stat-value {
    font-weight: 600;
    color: #1f2d3d;
  }
}

.price {
  font-size: 20px;
  font-weight: 600;
  color: #ff7b24;
}

.pager {
  text-align: right;
  margin-top: 16px;
}
</style>

