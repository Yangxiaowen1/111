<template>
  <div class="dashboard-screen" v-loading="loading">
    <section class="metrics-row">
      <div class="metric-card" v-for="item in metricList" :key="item.title">
        <p class="label">{{ item.title }}</p>
        <p class="value">{{ item.value }}</p>
      </div>
    </section>

    <section class="grid-row">
      <div class="panel wide" ref="mapChart"></div>
      <div class="panel" ref="trendChart"></div>
    </section>

    <section class="grid-row">
      <div class="panel" ref="scoreChart"></div>
      <div class="panel" ref="priceChart"></div>
      <div class="panel" ref="wordCloudChart"></div>
    </section>

    <section class="grid-row">
      <div class="panel table-panel card-panel">
        <div class="panel-title">高热度景点榜单</div>
        <div class="poi-card" v-for="item in visibleTopSites" :key="item.poiName">
          <div class="thumb" :style="backgroundStyle(item.imageUrl)"></div>
          <div class="poi-body">
            <div class="poi-head">
              <span class="poi-name">{{ item.poiName }}</span>
              <el-tag size="mini" effect="dark">{{ item.city || '未知地区' }}</el-tag>
            </div>
            <div class="poi-meta">
              <span>评分 {{ item.commentScore ?? '--' }}</span>
              <span>点评 {{ item.commentCount ?? '--' }}</span>
              <span>票价 {{ formatPrice(item.price) }}</span>
            </div>
            <p class="poi-desc">{{ item.description || '暂无简介，敬请期待更多内容。' }}</p>
            <div class="poi-actions">
              <a
                :href="item.detailUrl || 'javascript:void(0)'"
                target="_blank"
                rel="noopener"
                :class="{ disabled: !item.detailUrl }"
              >
                查看详情
              </a>
            </div>
          </div>
        </div>
      </div>
      <div style="height: auto" class="panel list-panel recommend-panel">
        <div class="panel-title">智能推荐</div>
        <div class="recommend-card" v-for="item in visibleRecommendations" :key="item.poiId">
          <div class="recommend-info">
            <div class="name-row">
              <span class="name">{{ item.name }}</span>
              <span class="score-tag">评分 {{ item.score ?? '--' }}</span>
            </div>
            <div class="meta">
              <span>{{ item.city || '热门目的地' }}</span>
              <span>票价 {{ formatPrice(item.price) }}</span>
            </div>
            <p class="desc">{{ item.description || 'AI 推荐人气路线，点击了解更多。' }}</p>
          </div>
          <a
            class="go-link"
            :href="item.detailUrl || 'javascript:void(0)'"
            target="_blank"
            rel="noopener"
            :class="{ disabled: !item.detailUrl }"
          >
            查看
          </a>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import 'echarts-wordcloud';
import chinaJson from '@/assets/china.json';
import { mapState } from 'vuex';

echarts.registerMap('china', chinaJson);

export default {
  name: 'Dashboard',
  data() {
    return {
      charts: {},
      fallbackImage: 'https://dummyimage.com/120x90/1b2a44/ffffff&text=Spot',
      topStartIndex: 0,
      recommendStartIndex: 0,
      scoreIndex: 0,
      topIntervalId: null,
      recommendIntervalId: null,
      scoreIntervalId: null
    };
  },
  computed: {
    ...mapState(['dashboard', 'loadingDashboard']),
    loading() {
      return this.loadingDashboard || !this.dashboard;
    },
    metricList() {
      if (!this.dashboard) return [];
      const cards = this.dashboard.cards || {};
      return [
        { title: '景点总量', value: cards.totalAttractions || 0 },
        { title: '平均评分', value: cards.avgScore || '--' },
        { title: '点评总数', value: cards.totalComments || 0 },
        { title: '高口碑景点', value: cards.highScorePlaces || 0 }
      ];
    },
    topSites() {
      const list = this.dashboard?.topTable || [];
      return list.map(item => ({
        ...item,
        imageUrl: item.imageUrl || this.fallbackImage
      }));
    },
    recommendCards() {
      return this.dashboard?.recommendations || [];
    },
    visibleTopSites() {
      const list = this.topSites;
      if (!list.length) return [];
      if (list.length <= 5) return list;
      const extended = [...list, ...list];
      return extended.slice(this.topStartIndex, this.topStartIndex + 5);
    },
    visibleRecommendations() {
      const list = this.recommendCards;
      if (!list.length) return [];
      if (list.length <= 5) return list;
      const extended = [...list, ...list];
      return extended.slice(this.recommendStartIndex, this.recommendStartIndex + 5);
    },
  },
  watch: {
    dashboard: {
      handler() {
        if (this.dashboard) {
          this.renderCharts();
          this.startScrolling();
        }
      },
      immediate: true
    }
  },
  mounted() {
    this.$store.dispatch('fetchDashboardData');
    window.addEventListener('resize', this.resizeCharts);
    this.startScrolling();
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resizeCharts);
    Object.values(this.charts).forEach(instance => instance?.dispose());
    this.stopScrolling();
  },
  methods: {
    getChart(refName) {
      const el = this.$refs[refName];
      if (!el) return null;
      if (!this.charts[refName]) {
        this.charts[refName] = echarts.init(el, null, { renderer: 'canvas' });
      }
      return this.charts[refName];
    },
    renderCharts() {
      this.renderMap();
      this.renderTrend();
      this.renderCategory();
      this.renderScore();
      this.renderPrice();
      this.renderWordCloud();
    },
    resizeCharts() {
      Object.values(this.charts).forEach(instance => instance?.resize());
    },
    startScrolling() {
      this.stopScrolling();
      if (this.topSites.length > 5) {
        this.topIntervalId = setInterval(() => {
          this.topStartIndex = (this.topStartIndex + 1) % this.topSites.length;
        }, 4000);
      } else {
        this.topStartIndex = 0;
      }
      if (this.recommendCards.length > 5) {
        this.recommendIntervalId = setInterval(() => {
          this.recommendStartIndex = (this.recommendStartIndex + 1) % this.recommendCards.length;
        }, 4500);
      } else {
        this.recommendStartIndex = 0;
      }
      if ((this.dashboard?.scoreDistribution || []).length > 5) {
        this.scoreIntervalId = setInterval(() => {
          const total = this.dashboard?.scoreDistribution?.length || 0;
          if (total) {
            this.scoreIndex = (this.scoreIndex + 1) % total;
            this.renderScore();
          }
        }, 4200);
      }
    },
    stopScrolling() {
      if (this.topIntervalId) {
        clearInterval(this.topIntervalId);
        this.topIntervalId = null;
      }
      if (this.recommendIntervalId) {
        clearInterval(this.recommendIntervalId);
        this.recommendIntervalId = null;
      }
      if (this.scoreIntervalId) {
        clearInterval(this.scoreIntervalId);
        this.scoreIntervalId = null;
      }
    },
    renderMap() {
      const chart = this.getChart('mapChart');
      if (!chart) return;
      if (!this.dashboard?.mapHeat?.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        backgroundColor: 'transparent',
        title: { text: '全国热度分布', left: 'center', textStyle: { color: '#c9deff' } },
        visualMap: {
          min: 0,
          max: 200,
          left: 'left',
          top: 'bottom',
          text: ['高', '低'],
          textStyle: { color: '#8ea0c4' },
          inRange: {
            color: ['#14243b', '#23456a', '#1f6feb', '#52d9ca']
          },
          calculable: true
        },
        series: [
          {
            name: '景点数量',
            type: 'map',
            map: 'china',
            roam: true,
            itemStyle: {
              borderColor: '#274158',
              areaColor: '#101c30'
            },
            emphasis: {
              itemStyle: {
                areaColor: '#1f6feb'
              }
            },
            data: this.dashboard?.mapHeat || []
          }
        ]
      });
    },
    renderTrend() {
      const chart = this.getChart('trendChart');
      if (!chart) return;
      const trend = this.dashboard?.scoreTrend || [];
      if (!trend.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        title: { text: '评分趋势', textStyle: { color: '#fff' } },
        xAxis: {
          type: 'category',
          data: trend.map(item => item.date),
          axisLine: { lineStyle: { color: '#4c81b7' } },
          axisLabel: { color: '#9cc9ff' }
        },
        yAxis: {
          type: 'value',
          axisLine: { lineStyle: { color: '#4c81b7' } },
          splitLine: { lineStyle: { color: '#1b2a44' } },
          axisLabel: { color: '#9cc9ff' }
        },
        series: [
          {
            data: trend.map(item => item.avgScore),
            type: 'line',
            smooth: true,
            areaStyle: {
              color: 'rgba(0, 136, 212, 0.3)'
            }
          }
        ]
      });
    },
    renderCategory() {
      const chart = this.getChart('categoryChart');
      if (!chart) return;
      if (!this.dashboard?.categoryBreakdown?.length) {
        chart.clear();
        return;
      }
      chart.setOption({
          title: { text: '品类占比', textStyle: { color: '#fff' } },
          tooltip: { trigger: 'item' },
          series: [
            {
              type: 'pie',
              radius: ['30%', '60%'],
              data: this.dashboard?.categoryBreakdown || [],
              label: { color: '#fff' }
            }
          ]
        });
    },
    renderScore() {
      const chart = this.getChart('scoreChart');
      if (!chart) return;
      const data = this.dashboard?.scoreDistribution || [];
      if (!data.length) {
        chart.clear();
        return;
      }
    const visible = [];
    if (data.length <= 5) {
      Array.prototype.push.apply(visible, data);
    } else {
      for (let i = 0; i < 5; i += 1) {
        visible.push(data[(this.scoreIndex + i) % data.length]);
      }
    }
      chart.setOption({
        title: { text: '评分分布', textStyle: { color: '#fff' } },
        xAxis: {
          type: 'category',
          data: visible.map(item => item.bucket || item.name || '未知'),
          axisLabel: { color: '#9cc9ff' }
        },
        yAxis: {
          type: 'value',
          axisLabel: { color: '#9cc9ff' },
          splitLine: { lineStyle: { color: '#1b2a44' } }
        },
        series: [
          {
            type: 'bar',
            data: visible.map(item => item.value),
            itemStyle: {
              color: '#00d2ff'
            }
          }
        ]
      });
    },
    renderPrice() {
      const chart = this.getChart('priceChart');
      if (!chart) return;
      const data = this.dashboard?.priceRange || [];
      if (!data.length) {
        chart.clear();
        return;
      }
      const maxValue = Math.max(...data.map(item => item.value || 0), 1);
      chart.setOption({
        title: { text: '票价区间', textStyle: { color: '#fff' } },
        tooltip: { trigger: 'axis' },
        radar: {
          indicator: data.map(item => ({
            name: item.priceBucket || item.name,
            max: maxValue
          })),
          name: { textStyle: { color: '#fff' } }
        },
        series: [
          {
            type: 'radar',
            data: [
              {
                value: data.map(item => item.value || 0),
                name: '票价'
              }
            ]
          }
        ]
      });
    },
    renderWordCloud() {
      const chart = this.getChart('wordCloudChart');
      if (!chart) return;
      if (!this.dashboard?.wordCloud?.length) {
        chart.clear();
        return;
      }
      chart.setOption({
        title: { text: '热搜词云', textStyle: { color: '#fff' } },
        series: [
          {
            type: 'wordCloud',
            gridSize: 6,
            sizeRange: [12, 50],
            rotationRange: [-45, 45],
            textStyle: {
              color: () => {
                const colors = ['#3a7bd5', '#00d2ff', '#4facfe', '#43e97b'];
                return colors[Math.floor(Math.random() * colors.length)];
              }
            },
            data: this.dashboard?.wordCloud || []
          }
        ]
      });
    },
    formatPrice(value) {
      if (value === null || value === undefined) return '——';
      return `¥${Number(value).toFixed(0)}`;
    },
    backgroundStyle(url) {
      return {
        backgroundImage: `url(${url || this.fallbackImage})`
      };
    }
  }
};
</script>

<style scoped lang="scss">
.dashboard-screen {
  padding: 24px;
  background: #0c1424;
  min-height: 100vh;
  color: #fff;
}

.metrics-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 20px;
}

.metric-card {
  background: linear-gradient(135deg, #1c2541, #0f3460);
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 8px 20px rgba(15, 52, 96, 0.4);
  .label {
    margin: 0;
    color: #9cc9ff;
  }
  .value {
    margin: 8px 0 0;
    font-size: 28px;
    font-weight: 600;
  }
}

.grid-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin-bottom: 20px;
}

.panel {
  background: #111c33;
  border-radius: 12px;
  padding: 12px;
  height: 320px;
}

.panel.wide {
  grid-column: span 2;
}

.panel-title {
  font-size: 16px;
  margin-bottom: 12px;
}

.table-panel {
  grid-column: span 2;
  height: auto;
}

.list-panel ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.list-panel li {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}

.list-panel .score {
  color: #43e97b;
}

.card-panel {
  display: flex;
  flex-direction: column;
}

.poi-card {
  display: flex;
  background: rgba(12, 23, 39, 0.85);
  border-radius: 12px;
  padding: 14px;
  margin-bottom: 12px;
  border: 1px solid rgba(58, 123, 213, 0.15);
}

.thumb {
  width: 120px;
  height: 90px;
  border-radius: 10px;
  background-size: cover;
  background-position: center;
  margin-right: 16px;
  flex-shrink: 0;
}

.poi-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.poi-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.poi-name {
  font-size: 18px;
  font-weight: 600;
}

.poi-meta {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #9cc9ff;
  margin-bottom: 4px;
}

.poi-desc {
  font-size: 13px;
  color: #bfcfe6;
  margin: 4px 0;
  line-height: 1.4;
  max-height: 36px;
  overflow: hidden;
}

.poi-actions a {
  color: #46f0ff;
  font-weight: 600;
}

.poi-actions a.disabled {
  color: #607095;
  cursor: not-allowed;
}

.recommend-panel {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.recommend-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(12, 23, 39, 0.85);
  border-radius: 12px;
  padding: 14px;
  margin-bottom: 12px;
  border: 1px solid rgba(79, 172, 254, 0.12);
}

.recommend-info {
  flex: 1;
  margin-right: 16px;
}

.name-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 600;
}

.score-tag {
  color: #43e97b;
  font-size: 13px;
}

.recommend-info .meta {
  font-size: 13px;
  color: #8ea0c4;
  display: flex;
  gap: 16px;
  margin: 4px 0;
}

.recommend-info .desc {
  font-size: 12px;
  color: #bfcfe6;
  margin: 0;
}

.go-link {
  color: #46f0ff;
  font-weight: 600;
}

.go-link.disabled {
  color: #607095;
  cursor: not-allowed;
}
</style>

