<template>
  <div class="auth-page">
    <el-card class="auth-card">
      <div slot="header" class="card-header">
        <span>用户登录</span>
        <small>旅游推荐运营平台</small>
      </div>
      <el-form :model="form" :rules="rules" ref="form" label-position="top">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="form.password" type="password" placeholder="请输入密码"></el-input>
        </el-form-item>
        <el-button type="primary" class="btn" :loading="loading" @click="handleLogin">登录</el-button>
        <el-button type="text" @click="$router.push('/register')">没有账号？去注册</el-button>
      </el-form>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data() {
    return {
      loading: false,
      form: {
        username: '',
        password: ''
      },
      rules: {
        username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
      }
    };
  },
  methods: {
    handleLogin() {
      this.$refs.form.validate(async valid => {
        if (!valid) return;
        this.loading = true;
        try {
          await this.$store.dispatch('login', this.form);
          await this.$store.dispatch('fetchDashboardData');
          this.$router.push('/big-screen');
        } catch (error) {
          this.$message.error(error.response?.data?.detail || '登录失败');
        } finally {
          this.loading = false;
        }
      });
    }
  }
};
</script>

<style scoped lang="scss">
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #f5f7fa, #e0f7ff);
}

.auth-card {
  width: 420px;
}

.card-header {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
  span {
    font-size: 20px;
    font-weight: 600;
  }
  small {
    color: #909399;
  }
}

.btn {
  width: 100%;
  margin-top: 12px;
}
</style>

