<template>
  <div class="user-profile-page">
    <el-card class="profile-card" v-loading="loading">
      <div slot="header" class="card-header">
        <span>个人信息</span>
        <small>修改您的个人资料</small>
      </div>
      <el-form :model="form" :rules="rules" ref="form" label-width="100px">
        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="用户名" prop="username">
              <el-input v-model="form.username" disabled></el-input>
              <small class="form-hint">用户名不可修改</small>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="昵称" prop="nickname">
              <el-input v-model="form.nickname" placeholder="请输入昵称" maxlength="50"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="邮箱" prop="email">
              <el-input v-model="form.email" type="email" placeholder="请输入邮箱地址"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="手机号" prop="phone">
              <el-input v-model="form.phone" placeholder="请输入手机号" maxlength="20"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row :gutter="24">
          <el-col :span="12">
            <el-form-item label="性别" prop="gender">
              <el-select v-model="form.gender" placeholder="请选择性别" style="width: 100%">
                <el-option label="男" value="male"></el-option>
                <el-option label="女" value="female"></el-option>
                <el-option label="未知" value="unknown"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="城市" prop="city">
              <el-input v-model="form.city" placeholder="请输入所在城市" maxlength="50"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="头像URL" prop="avatar">
          <el-input v-model="form.avatar" placeholder="请输入头像图片URL"></el-input>
          <small class="form-hint">支持外部图片链接</small>
        </el-form-item>

        <el-form-item label="头像预览">
          <div class="avatar-preview">
            <el-avatar :size="80" :src="form.avatar || ''">
              {{ form.nickname || form.username || 'U' }}
            </el-avatar>
          </div>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="saving" @click="handleSave">保存修改</el-button>
          <el-button @click="handleReset">重置</el-button>
          <el-button type="text" @click="$router.back()">返回</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  name: 'UserProfile',
  data() {
    return {
      loading: false,
      saving: false,
      form: {
        username: '',
        nickname: '',
        email: '',
        phone: '',
        gender: 'unknown',
        city: '',
        avatar: ''
      },
      originalForm: {},
      rules: {
        email: [
          { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
        ],
        phone: [
          { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号', trigger: 'blur' }
        ]
      }
    };
  },
  computed: {
    ...mapState(['currentUser'])
  },
  mounted() {
    this.fetchProfile();
  },
  methods: {
    async fetchProfile() {
      this.loading = true;
      try {
        const { data } = await this.$store.dispatch('fetchUserProfile');
        this.form = {
          username: data.username || '',
          nickname: data.nickname || '',
          email: data.email || '',
          phone: data.phone || '',
          gender: data.gender || 'unknown',
          city: data.city || '',
          avatar: data.avatar || ''
        };
        this.originalForm = { ...this.form };
      } catch (error) {
        this.$message.error(error.response?.data?.detail || '获取用户信息失败');
      } finally {
        this.loading = false;
      }
    },
    async handleSave() {
      this.$refs.form.validate(async valid => {
        if (!valid) return;
        this.saving = true;
        try {
          await this.$store.dispatch('updateUserProfile', this.form);
          this.$message.success('保存成功');
          this.originalForm = { ...this.form };
        } catch (error) {
          this.$message.error(error.response?.data?.detail || '保存失败');
        } finally {
          this.saving = false;
        }
      });
    },
    handleReset() {
      this.form = { ...this.originalForm };
      this.$refs.form.clearValidate();
    }
  }
};
</script>

<style scoped lang="scss">
.user-profile-page {
  min-height: calc(100vh - 64px);
  padding: 24px;
  background: #f5f7fa;
}

.profile-card {
  max-width: 900px;
  margin: 0 auto;
}

.card-header {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
  span {
    font-size: 20px;
    font-weight: 600;
    color: #303133;
  }
  small {
    color: #909399;
    font-size: 14px;
    margin-top: 4px;
  }
}

.form-hint {
  display: block;
  color: #909399;
  font-size: 12px;
  margin-top: 4px;
}

.avatar-preview {
  display: flex;
  align-items: center;
  padding: 12px 0;
}

:deep(.el-form-item__label) {
  font-weight: 500;
  color: #606266;
}

:deep(.el-input.is-disabled .el-input__inner) {
  background-color: #f5f7fa;
  color: #606266;
}
</style>

