import axios from 'axios';

const api = axios.create({
  baseURL: process.env.VUE_APP_API_BASE || 'http://127.0.0.1:8000/api'
});

api.interceptors.request.use(config => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Token ${token}`;
  }
  return config;
});

export default api;

