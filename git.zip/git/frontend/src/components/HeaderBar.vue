<template>
  <div class="header">
    <div class="logo">旅游推荐运营平台</div>
    <el-menu
      v-if="!isBigScreen"
      mode="horizontal"
      :default-active="active"
      @select="handleSelect"
    >
      <el-menu-item index="/home">首页仪表盘</el-menu-item>
      <el-menu-item index="/big-screen">运营大屏</el-menu-item>
      <el-menu-item index="/attractions">旅游数据</el-menu-item>
      <el-menu-item index="/insights/condition">条件洞察</el-menu-item>
      <el-menu-item index="/insights/price">票价分析</el-menu-item>
      <el-menu-item index="/insights/family">亲子洞察</el-menu-item>
      <el-menu-item index="/insights/media">媒介体验</el-menu-item>
      <el-menu-item index="/recommend/user-cf">用户协同推荐</el-menu-item>
      <el-menu-item index="/recommend/multimodal">多模态推荐</el-menu-item>
      <el-menu-item index="/recommend/dnn-rank">深度学习排序</el-menu-item>
    </el-menu>
    <div class="spacer"></div>
    <el-button
      v-if="isBigScreen"
      size="mini"
      type="primary"
      class="home-link"
      @click="$router.push('/home')"
    >
      返回首页仪表盘
    </el-button>
    <el-dropdown v-if="isAuthenticated" @command="handleCommand" trigger="click">
      <div class="user-info">
        <el-avatar :size="36" :src="avatarUrl">{{ initials }}</el-avatar>
        <div class="meta">
          <span class="name">{{ displayName }}</span>
          <small>{{ roleLabel }}</small>
        </div>
      </div>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="profile">
          <i class="el-icon-user"></i> 个人资料
        </el-dropdown-item>
        <el-dropdown-item divided command="logout">
          <i class="el-icon-switch-button"></i> 退出登录
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
import { mapGetters, mapState } from 'vuex';
export default {
  name: 'HeaderBar',
  data() {
    return {
      active: '/home'
    };
  },
  computed: {
    ...mapGetters(['isAuthenticated']),
    ...mapState(['currentUser']),
    isBigScreen() {
      return this.$route.name === 'big-screen';
    },
    displayName() {
      return this.currentUser?.nickname || this.currentUser?.username || '未登录';
    },
    roleLabel() {
      return '运营管理员';
    },
    avatarUrl() {
      return this.currentUser?.avatar || '';
    },
    initials() {
      const name = this.currentUser?.nickname || this.currentUser?.username || 'U';
      return name.slice(0, 1).toUpperCase();
    }
  },
  methods: {
    handleSelect(index) {
      if (index) {
        this.$router.push(index);
      }
    },
    handleCommand(command) {
      if (command === 'profile') {
        this.$router.push('/profile');
      } else if (command === 'logout') {
        this.logout();
      }
    },
    logout() {
      this.$store.dispatch('logout');
      this.$router.push('/login');
    }
  },
  watch: {
    $route: {
      immediate: true,
      handler(route) {
        this.active = route.meta?.menuKey || route.path;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.header {
  display: flex;
  align-items: center;
  background: linear-gradient(90deg, #101b2d, #16243d 40%, #0c1727);
  color: #fff;
  padding: 0 24px;
  height: 64px;
  box-shadow: 0 8px 24px rgba(5, 9, 20, 0.6);
}

.logo {
  font-size: 20px;
  font-weight: 600;
  margin-right: 24px;
}

:deep(.el-menu.el-menu--horizontal) {
  background-color: transparent;
  border-bottom: none;
}

:deep(.el-menu-item) {
  color: #8ea0c4 !important;
  font-size: 15px;
  margin: 0 6px;
  transition: all 0.2s;
}

:deep(.el-menu-item.is-active) {
  background: rgba(255, 255, 255, 0.1) !important;
  color: #ffffff !important;
  border-bottom: 2px solid #3fa9f5 !important;
}

.spacer {
  flex: 1;
}

.user-info {
  display: flex;
  align-items: center;
  margin-right: 12px;
  padding: 4px 10px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.07);
  cursor: pointer;
  transition: all 0.2s;
  &:hover {
    background: rgba(255, 255, 255, 0.12);
  }
  .meta {
    display: flex;
    flex-direction: column;
    margin-left: 8px;
    .name {
      font-weight: 600;
      line-height: 1.1;
    }
    small {
      color: #8ea0c4;
      font-size: 12px;
    }
  }
}

.logout {
  color: #67c1f5;
  font-weight: 600;
}

.home-link {
  margin-right: 16px;
}
</style>

