<template>
  <div class="chart-card">
    <div class="card-head">
      <div class="title">{{ title }}</div>
      <slot name="extra"></slot>
    </div>
    <div class="card-body" :style="{ height }" ref="chart"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import 'echarts-wordcloud';

export default {
  name: 'EChartCard',
  props: {
    title: {
      type: String,
      default: ''
    },
    options: {
      type: Object,
      default: () => ({})
    },
    height: {
      type: String,
      default: '260px'
    }
  },
  data() {
    return {
      chart: null
    };
  },
  watch: {
    options: {
      deep: true,
      handler() {
        this.renderChart();
      }
    }
  },
  mounted() {
    this.chart = echarts.init(this.$refs.chart, null, { renderer: 'canvas' });
    this.renderChart();
    window.addEventListener('resize', this.handleResize);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize);
    if (this.chart) {
      this.chart.dispose();
    }
  },
  methods: {
    handleResize() {
      this.chart?.resize();
    },
    renderChart() {
      if (!this.chart || !this.options || Object.keys(this.options).length === 0) {
        this.chart?.clear();
        return;
      }
      this.chart.setOption(this.options, true);
    }
  }
};
</script>

<style scoped lang="scss">
.chart-card {
  background: #ffffff;
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
}

.card-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  .title {
    font-size: 15px;
    font-weight: 600;
    color: #303133;
  }
}

.card-body {
  flex: 1;
  width: 100%;
}
</style>

