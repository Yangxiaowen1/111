import Vue from 'vue';
import Router from 'vue-router';
import store from '@/store';
import Dashboard from '@/views/Dashboard.vue';
import HomeDashboard from '@/views/HomeDashboard.vue';
import Login from '@/views/Login.vue';
import Register from '@/views/Register.vue';
import UserProfile from '@/views/UserProfile.vue';
import AttractionList from '@/views/AttractionList.vue';
import AttractionDetail from '@/views/AttractionDetail.vue';
import ConditionAnalytics from '@/views/insights/ConditionAnalytics.vue';
import PriceAnalytics from '@/views/insights/PriceAnalytics.vue';
import FamilyAnalytics from '@/views/insights/FamilyAnalytics.vue';
import MediaAnalytics from '@/views/insights/MediaAnalytics.vue';
import UserCF from '@/views/recommend/UserCF.vue';
import MultimodalRecommend from '@/views/recommend/Multimodal.vue';
import DNNRank from '@/views/recommend/DNNRank.vue';

Vue.use(Router);

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/home',
      name: 'home',
      component: HomeDashboard,
      meta: { requiresAuth: true }
    },
    {
      path: '/big-screen',
      name: 'big-screen',
      component: Dashboard,
      meta: { requiresAuth: true }
    },
    {
      path: '/attractions',
      name: 'attractions',
      component: AttractionList,
      meta: { requiresAuth: true }
    },
    {
      path: '/attractions/:poiId',
      name: 'attraction-detail',
      component: AttractionDetail,
      props: true,
      meta: { requiresAuth: true, menuKey: '/attractions' }
    },
    {
      path: '/insights/condition',
      name: 'insight-condition',
      component: ConditionAnalytics,
      meta: { requiresAuth: true }
    },
    {
      path: '/insights/price',
      name: 'insight-price',
      component: PriceAnalytics,
      meta: { requiresAuth: true }
    },
    {
      path: '/insights/family',
      name: 'insight-family',
      component: FamilyAnalytics,
      meta: { requiresAuth: true }
    },
    {
      path: '/insights/media',
      name: 'insight-media',
      component: MediaAnalytics,
      meta: { requiresAuth: true }
    },
    {
      path: '/recommend/user-cf',
      name: 'user-cf',
      component: UserCF,
      meta: { requiresAuth: true }
    },
    {
      path: '/recommend/multimodal',
      name: 'multimodal',
      component: MultimodalRecommend,
      meta: { requiresAuth: true }
    },
    {
      path: '/recommend/dnn-rank',
      name: 'dnn-rank',
      component: DNNRank,
      meta: { requiresAuth: true }
    },
    {
      path: '/login',
      name: 'login',
      component: Login,
      meta: { public: true }
    },
    {
      path: '/register',
      name: 'register',
      component: Register,
      meta: { public: true }
    },
    {
      path: '/profile',
      name: 'profile',
      component: UserProfile,
      meta: { requiresAuth: true }
    }
  ]
});

router.beforeEach((to, from, next) => {
  const isAuthed = store.getters.isAuthenticated;
  if (to.meta.requiresAuth && !isAuthed) {
    next({ name: 'login' });
    return;
  }
  if ((to.name === 'login' || to.name === 'register') && isAuthed) {
    next({ name: 'home' });
    return;
  }
  next();
});

export default router;
