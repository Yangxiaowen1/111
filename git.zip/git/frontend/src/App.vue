<template>
  <div id="app">
    <header-bar v-if="showHeader" />
    <router-view />
  </div>
</template>

<script>
import HeaderBar from './components/HeaderBar.vue';
import { mapGetters } from 'vuex';

export default {
  name: 'App',
  components: {
    HeaderBar
  },
  computed: {
    ...mapGetters(['isAuthenticated']),
    showHeader() {
      return this.isAuthenticated;
    }
  }
};
</script>

<style lang="scss">
html,
body {
  margin: 0;
  padding: 0;
  min-height: 100vh;
  background: #050914;
  font-family: 'DIN Alternate', 'PingFang SC', 'Microsoft YaHei', sans-serif;
}

* {
  box-sizing: border-box;
}

#app {
  min-height: 100vh;
  background: #050914;
}
</style>

