import Vue from 'vue';
import Vuex from 'vuex';
import api from '@/services/api';

Vue.use(Vuex);

const tokenFromStorage = localStorage.getItem('auth_token');

export default new Vuex.Store({
  state: {
    token: tokenFromStorage || '',
    currentUser: null,
    dashboard: null,
    loadingDashboard: false,
    indexDashboard: null,
    loadingIndex: false
  },
  mutations: {
    setToken(state, token) {
      state.token = token;
      if (token) {
        localStorage.setItem('auth_token', token);
      } else {
        localStorage.removeItem('auth_token');
      }
    },
    setCurrentUser(state, user) {
      state.currentUser = user;
    },
    setDashboard(state, payload) {
      state.dashboard = payload;
    },
    setLoadingDashboard(state, flag) {
      state.loadingDashboard = flag;
    },
    setIndexDashboard(state, payload) {
      state.indexDashboard = payload;
    },
    setLoadingIndex(state, flag) {
      state.loadingIndex = flag;
    }
  },
  actions: {
    async register({ commit }, form) {
      const { data } = await api.post('/auth/register/', form);
      commit('setToken', data.token);
      commit('setCurrentUser', data.user);
    },
    async login({ commit, dispatch }, form) {
      const { data } = await api.post('/auth/login/', form);
      commit('setToken', data.token);
      commit('setCurrentUser', data.user);
      // 登录后获取完整的用户资料信息
      await dispatch('fetchUserProfile');
    },
    async fetchProfile({ commit, state }) {
      if (!state.token) return;
      try {
        const { data } = await api.get('/auth/me/');
        commit('setCurrentUser', data);
      } catch (error) {
        // 如果获取失败，清除 token
        console.error('获取用户信息失败:', error);
        commit('setToken', '');
      }
    },
    async fetchUserProfile({ commit, state }) {
      if (!state.token) return;
      const { data } = await api.get('/auth/me/');
      commit('setCurrentUser', data);
      return { data };
    },
    async updateUserProfile({ commit, state }, formData) {
      if (!state.token) throw new Error('未登录');
      const { data } = await api.patch('/auth/me/', formData);
      commit('setCurrentUser', data);
      return { data };
    },
    logout({ commit }) {
      commit('setToken', '');
      commit('setCurrentUser', null);
      commit('setDashboard', null);
      commit('setIndexDashboard', null);
    },
    async fetchDashboardData({ commit }) {
      commit('setLoadingDashboard', true);
      try {
        const { data } = await api.get('/dashboard/summary/');
        commit('setDashboard', data);
      } finally {
        commit('setLoadingDashboard', false);
      }
    },
    async fetchIndexDashboard({ commit }) {
      commit('setLoadingIndex', true);
      try {
        const { data } = await api.get('/dashboard/index/');
        commit('setIndexDashboard', data);
      } finally {
        commit('setLoadingIndex', false);
      }
    }
  },
  getters: {
    isAuthenticated: state => Boolean(state.token)
  }
});

